var eventModal = $('#eventModal');
var modalTitle = $('.modal-title');
var editTitle = $('#edit-title');
var editStart = $('#edit-start');
var editEnd = $('#edit-end');
var editType = $('#edit-type');
var editColor = $('#edit-color');
var editDesc = $('#edit-desc');

var addBtnContainer = $('.modalBtnContainer-addEvent');
var modifyBtnContainer = $('.modalBtnContainer-modifyEvent');



// 새로운 일정 생성

var newEvent = function (start, end) {
    eventModal.find('input, textarea').val('');

    $("#contextMenu").hide(); //메뉴 숨김

    modalTitle.html('새로운 일정');
    
    editStart.val(start);
    editEnd.val(end);


    addBtnContainer.show();
    modifyBtnContainer.hide();
    eventModal.modal('show');

    var eventId = 1 + Math.floor(Math.random() * 1000);
    
    //새로운 일정 저장버튼 클릭
    $('#save-event').unbind();
    $('#save-event').on('click', function () {

        var eventData = {
            /*_id: eventId,*/
            title: editTitle.val(),
            start: editStart.val(),
            end: editEnd.val(),
            description: editDesc.val(),
            backgroundColor: editColor.val(),
            textColor: '#ffffff',
            allDay: true
        };

        if (eventData.start > eventData.end) {
            alert('끝나는 날짜가 앞설 수 없습니다.');
            return false;
        }

        if (eventData.title === '') {
            alert('일정명은 필수입니다.');
            return false;
        }
    
        eventModal.find('input, textarea').val('');
        eventModal.modal('hide');

        //새로운 일정 저장
        $.ajax({
            type: "post",
            url: "./calendar/addc.jsp",
            data: {
            	"id": eventId,
                "title": eventData.title,
                "start": eventData.start,
                "end": eventData.end,
                "detail": eventData.description,
                "bg_color": eventData.backgroundColor,
                
            },
            success: function (response) {
            	
            	console.log(response);
            	location.replace('schedule.seo');

            },
            error : function(){
            	console.log("통신 에러다");
            }
        });
    });
};
	