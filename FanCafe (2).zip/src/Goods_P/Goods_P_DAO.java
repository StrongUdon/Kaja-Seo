package Goods_P;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Goods.GoodsVO;
import util.DBConn;

public class Goods_P_DAO implements Goods_P_IDAO{

	private Connection con; 

	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public Goods_P_DAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection(); 
		
	}
	

	public boolean insert(String p_num, int m_num,int g_num, int amount) throws SQLException {
		
		String sql = "insert into purchases values(?,?,?,?,sysdate,'0')";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, p_num);
		pstmt.setInt(2, g_num);
		pstmt.setInt(3, m_num);
		pstmt.setInt(4, amount);

		if (pstmt.executeUpdate() == 1) {
			System.out.println("인서트 성공");
			return true;			
		}
		System.out.println("인서트 실패");
		return false;
	}
	
	public ArrayList<Goods_P_VO> getAllPurchased(int m_no)  
			throws SQLException{
		ArrayList<Goods_P_VO> list
		               = new ArrayList<Goods_P_VO>();
		String sql 
		= "SELECT * FROM PURCHASES where m_no =? "
				+ " ORDER BY purchased_at";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, m_no);
		rs = pstmt.executeQuery();
		while(rs.next()){

			String p_no = rs.getString("p_no");
			int g_no1 = rs.getInt("g_no");
			int amount = rs.getInt("amount");
			String purchased_at = rs.getString("purchased_at");

			String is_review = rs.getString("is_review");
			
			Goods_P_VO gpvo = new Goods_P_VO(p_no,m_no,g_no1,amount,purchased_at,is_review);
			list.add(gpvo);
		}
		return list;
	}
	public Goods_P_VO getLatest()  
			throws SQLException{
		Goods_P_VO gpvo = null;
		               
		String sql = " select * from"
				+ "(select * from purchases order by purchased_at desc)" 
				+  "where rownum=1";
		pstmt = con.prepareStatement(sql);

		rs = pstmt.executeQuery();
		while(rs.next()){

			String p_no = rs.getString("p_no");
			int m_no = rs.getInt("m_no");
			int g_no1 = rs.getInt("g_no");
			int amount = rs.getInt("amount");
			String purchased_at = rs.getString("purchased_at");
			String is_review = rs.getString("is_review");
			
			gpvo = new Goods_P_VO(p_no,m_no,g_no1,amount,purchased_at,is_review);

		}
		return gpvo;
	}
	
}
