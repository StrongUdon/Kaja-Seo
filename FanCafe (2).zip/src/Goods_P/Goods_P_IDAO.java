package Goods_P;

import java.sql.SQLException;
import java.util.ArrayList;

public interface Goods_P_IDAO {

	public boolean insert(String p_num, int g_num, int m_num, int amount) throws SQLException;
	//결제내역 삽입
	
	public ArrayList<Goods_P_VO> getAllPurchased(int m_no) throws SQLException;
	//m_no의 모든 결제내역 return 

	public Goods_P_VO getLatest() throws SQLException;
	//가장 최근 결제내역 return
}
