package Goods_P;

public class Goods_P_VO {

	private String p_no;
	private int m_no;
	private int g_no;
	private int amount;
	private String purchased_at;
	private String is_review;

	public Goods_P_VO(String p_no, int m_no, int g_no, int amount, String purchased_at, String is_review) {
		super();
		this.p_no = p_no;
		this.m_no = m_no;
		this.g_no = g_no;
		this.amount = amount;
		this.purchased_at = purchased_at;
		this.is_review = is_review;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public int getG_no() {
		return g_no;
	}

	public void setG_no(int g_no) {
		this.g_no = g_no;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getpurchased_at() {
		return purchased_at;
	}

	public void setpurchased_at(String purchased_at) {
		this.purchased_at = purchased_at;
	}

	public String getIs_review() {
		return is_review;
	}

	public void setIs_review(String is_review) {
		this.is_review = is_review;
	}

	@Override
	public String toString() {
		return "Goods_P_VO [p_no=" + p_no + ", m_no=" + m_no + ", g_no=" + g_no + ", amount=" + amount
				+ ", purchased_at=" + purchased_at + ", is_review=" + is_review + "]";
	}

}
