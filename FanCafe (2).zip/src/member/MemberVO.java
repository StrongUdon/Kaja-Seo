package member;

/*
웹사이트 회원 테이블
M_NO: 정수로 된 회원번호 (기본키)
EMAIL: 이메일
PIC_URI: 프로필사진 URI
PW: 비밀번호
M_NAME: 닉네임, 공백가능
PNUM: 전화번호
IS_SNS: SNS계정 여부(BOOLEAN). 한개의 캐릭터만 받으며 '1' = TRUE (소셜계정) '0' = FALSE (일반계정)
IS_ADMIN: 등급(BOOLEAN). '1' = TRUE (관리자 등급) '0' = FALSE (일반 등급),

CREATE TABLE Members(
    M_NO INTEGER,
    EMAIL VARCHAR2(50) NOT NULL UNIQUE,
    PIC_URI VARCHAR2(300),
    PW VARCHAR2(40) NOT NULL,
    M_NAME VARCHAR2(20) UNIQUE,
    PNUM VARCHAR2(11) NOT NULL UNIQUE,
    IS_SNS CHAR(1) DEFAULT '0',
    IS_ADMIN CHAR(1) DEFAULT '0',
    CONSTRAINT MEMBER_PK PRIMARY KEY(M_NO),
    CONSTRAINT MEMBER_SNS_CK CHECK ((IS_SNS = '1') OR (IS_SNS = '0')),
    CONSTRAINT MEMBER_ADMIN_CK CHECK ((IS_ADMIN = '1') OR (IS_ADMIN = '0'))
);
*/

public class MemberVO {
	private int m_no;
	private String email;
	private String pw;
	private String pic_uri;
	private String pnum;
	private String m_name;
	private boolean is_sns;
	private boolean is_admin;
	
	public MemberVO() {
		// TODO Auto-generated constructor stub
	}

	public MemberVO(int m_no, String email, String pw, String pic_uri, String pnum, String m_name, boolean is_sns,
			boolean is_admin) {
		super();
		this.m_no = m_no;
		this.email = email;
		this.pw = pw;
		this.pic_uri = pic_uri;
		this.pnum = pnum;
		this.m_name = m_name;
		this.is_sns = is_sns;
		this.is_admin = is_admin;
	}

	
	public MemberVO(int m_no, String email, String pw, String pic_uri, String pnum, String m_name, boolean is_admin) {
		super();
		this.m_no = m_no;
		this.email = email;
		this.pw = pw;
		this.pic_uri = pic_uri;
		this.pnum = pnum;
		this.m_name = m_name;
		this.is_admin = is_admin;
	}
	
	public MemberVO(String m_name) {
		super();
		this.m_name=m_name;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getPic_uri() {
		return pic_uri;
	}

	public void setPic_uri(String pic_uri) {
		this.pic_uri = pic_uri;
	}

	public String getPnum() {
		return pnum;
	}

	public void setPnum(String pnum) {
		this.pnum = pnum;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public boolean isIs_sns() {
		return is_sns;
	}

	public void setIs_sns(boolean is_sns) {
		this.is_sns = is_sns;
	}

	public boolean isIs_admin() {
		return is_admin;
	}

	public void setIs_admin(boolean is_admin) {
		this.is_admin = is_admin;
	}

	@Override
	public String toString() {
		return "MemberVO [m_no=" + m_no + ", email=" + email + ", pw=" + pw + ", pic_uri=" + pic_uri + ", pnum=" + pnum
				+ ", m_name=" + m_name + ", is_sns=" + is_sns + ", is_admin=" + is_admin + "]";
	}

	
}
