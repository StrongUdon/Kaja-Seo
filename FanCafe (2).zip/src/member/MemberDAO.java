package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBConn;

public class MemberDAO implements MemberIDAO {

	private Connection con; // MemberConn

	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public MemberDAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection(); // getConnection 메소드를 실행
												// return 값인 con을 이 클래스의 con에 넣음
												// 결과적으로 이 클래스의 con에는 DBConn 접속 객체가 들어감
	}

	@Override
	public boolean insert(MemberVO mvo) {

		String sql = " INSERT INTO MEMBERS ( "
				+ " M_NO, EMAIL, PW, PIC_URI, M_NAME, PNUM, IS_SNS, IS_ADMIN ) "
				+ "  VALUES(MEMBER_INCREMENT.NEXTVAL, ?, ?, ?, ?, ?, ?, ?) ";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mvo.getEmail());
			pstmt.setString(2, mvo.getPw());
			pstmt.setString(3, mvo.getPic_uri());
			pstmt.setString(4, mvo.getM_name());
			pstmt.setString(5, mvo.getPnum());
			pstmt.setBoolean(6, mvo.isIs_sns());
			pstmt.setBoolean(7, mvo.isIs_admin());

			if (pstmt.executeUpdate() == 1) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Insert Exception");
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public MemberVO getOneInfo(String email, String pw) throws SQLException {
		String sql = "SELECT * FROM MEMBERS "
				+ "	WHERE EMAIL = ? "
				+ " AND PW = ? ";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, email);
		pstmt.setString(2, pw);
		rs = pstmt.executeQuery();
		MemberVO mvo = new MemberVO();
		if (rs.next()) {
			int m_no = rs.getInt("m_no");
			String memail = rs.getString("email");
			String mpw = rs.getString("pw");
			String pic_uri = rs.getString("pic_uri");
			String pnum = rs.getString("pnum");
			String m_name = rs.getString("m_name");
			boolean is_sns = rs.getBoolean("is_sns");
			boolean is_admin = rs.getBoolean("is_admin");
			mvo = new MemberVO(m_no, memail, mpw, pic_uri, pnum, m_name, is_sns, is_admin );
			return mvo;
		}
		return null;
	}

	 public int howManyMem() throws SQLException {

	      String sql = "select count(*) from members";
	      pstmt = con.prepareStatement(sql);
	      rs = pstmt.executeQuery();
	      if(rs.next()) {
	         return rs.getInt(1) + 1;
	      }else {
	         return 0;
	      }
	   }// 자동 번호 증가 메서드 (셀렉해서 멤버 인원 수 파악하고 +1 해서 반환) 
	   

	   @Override
	   public boolean change_info(String email, String m_name, String pnum) {

	      String sql = "update members set m_name = ?, pnum = ? where email = ?";
	      try {
	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, m_name);
	         pstmt.setString(2, pnum);
	         pstmt.setString(3, email);
	         pstmt.executeUpdate();
	      } catch (SQLException e) {
	         System.out.println("Update Exception");
	         return false;
	      }
	      return true;
	   } // 닉네임/전화번호 변경 메서드

	   @Override
	   public boolean change_pw(String email, String pw) {

	      String sql = "update members set pw = ? where email = ?";
	      try {
	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, pw);
	         pstmt.setString(2, email);
	         pstmt.executeUpdate();
	      } catch (SQLException e) {
	         System.out.println("Update Exception");
	         return false;
	      }
	      return true;
	   } // 비밀번호 변경 메서드

	   @Override
	   public boolean delete(int m_no) {
	      String sql = "delete from members where m_no = ?";
	      try {
	         pstmt = con.prepareStatement(sql);
	         pstmt.setInt(1, m_no);
	         pstmt.executeUpdate();
	      } catch (SQLException e) {
	    	 e.printStackTrace();
	         return false;
	      }
	      return true;
	   }

	   @Override
	   public boolean IsOverRap(String str, String value) throws SQLException {

	      String sql = "select * from members where "+str+" = ?";
	            
	      PreparedStatement ps = con.prepareStatement(sql);

	      ps.setString(1, value);

	      rs = ps.executeQuery();

	      if (rs.next())
	         return true;
	      else
	         return false;
	   }
	   
	     
	   @Override
	   public MemberVO getOneInfo(String email) throws SQLException {
	      String sql = "select * from members where email = ?";
	      pstmt = con.prepareStatement(sql);
	      pstmt.setString(1, email);
	      rs = pstmt.executeQuery();
	      MemberVO mv = new MemberVO();
	      if (rs.next()) {	         
	         int member_no = rs.getInt("m_no");
	         String pw = rs.getString("pw");
	         String pnum = rs.getString("pnum");
	         String m_name = rs.getString("m_name");
	         mv = new MemberVO(member_no, email, pw, rs.getString("pic_uri"), pnum, m_name, rs.getBoolean("is_sns"), rs.getBoolean("is_admin"));
	     
	      }
	      return mv;
	   }

	   @Override
	   public ArrayList<MemberVO> getAllInfo() throws SQLException {

	      ArrayList<MemberVO> mem_list = new ArrayList<>();
	      String sql = "select * from members order by m_no";
	      pstmt = con.prepareStatement(sql);
	      rs = pstmt.executeQuery();
	      while (rs.next()) {
	         int m_no = rs.getInt("m_no");
	         String email = rs.getString("email");
	         String pw = rs.getString("pw");
	         String pic_uri = rs.getString("pic_uri");
	         String pnum = rs.getString("pnum");
	         String m_name = rs.getString("m_name");
	         boolean is_sns = rs.getBoolean("is_sns");
	         boolean is_admin = rs.getBoolean("is_admin");
	         MemberVO mv = new MemberVO(m_no, email, pw, pic_uri, pnum,  m_name, is_sns, is_admin);
	         
	         mem_list.add(mv);
	      }
	      return mem_list;
	   }

	   
		@Override
		public MemberVO findMemberByMno(int mno ) throws SQLException {
			String sql = "SELECT * FROM MEMBERS "
					+ "	WHERE m_no = ? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, mno);
			rs = pstmt.executeQuery();
			MemberVO mvo = new MemberVO();
			if (rs.next()) {
				int m_no = rs.getInt("m_no");
				String memail = rs.getString("email");
				String mpw = rs.getString("pw");
				String pic_uri = rs.getString("pic_uri");
				String pnum = rs.getString("pnum");
				String m_name = rs.getString("m_name");
				boolean is_sns = rs.getBoolean("is_sns");
				boolean is_admin = rs.getBoolean("is_admin");
				mvo = new MemberVO(m_no, memail, mpw, pic_uri, pnum, m_name, is_sns, is_admin );
				return mvo;
			}
			return null;
		}
	   
	   
	public void pstmtClose() throws SQLException {
		if (pstmt != null)
			pstmt.close();
	}
}
