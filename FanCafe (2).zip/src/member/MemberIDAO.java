package member;

import java.sql.SQLException;
import java.util.ArrayList;

public interface MemberIDAO {

	public boolean insert(MemberVO mvo);
	// 회원 가입(MemberVO 받아서 성공/실패 반환)
	 
	   public boolean change_info(String email, String nickname, String pnum);
	   // 수정(email 받아서 닉네임/전화번호 변경 성공/실패 반환)

	   public boolean change_pw(String email, String pw);
	   // 수정(email 받아서 비밀번호 변경 성공/실패 반환)
	   
	   public boolean delete(int member_no);
	   // 회원 탈퇴(member_no 받아서 성공/실패 반환) 
	   // 여기서는 번호만 받지만 controller에서 비밀번호 확인이 당연히 들어감

	   public boolean IsOverRap(String str, String value) throws SQLException;
	   // 이메일/닉네임/전화번호 중복체크
	   
	   public MemberVO getOneInfo(String email) throws SQLException;
	   // 마이페이지(email받아서 MemberVO 전체 반환)
	   
	   public ArrayList<MemberVO> getAllInfo() throws SQLException ;
	   // 회원 전체 정보 반환 (관리자용)
	   
	public MemberVO getOneInfo(String email, String pw) throws SQLException;
	// 마이페이지(email받아서 MemberVO 전체 반환)
	
	public MemberVO findMemberByMno(int m_no) throws SQLException;

}
