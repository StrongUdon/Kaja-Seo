package review;

import java.util.Date;

public class ReviewVO {
	private int r_no;
	private int g_no;
	private int m_no;
	private String content;
	private String img_uri;
	private int s_rate; //dao에 final 선언하기
	private int g_rate;
	private Date created_at;
	private Date modified_at;
	private int r_parent;
	private int r_depth;
	private int r_order;
	
	public ReviewVO() {}
	
	
	public ReviewVO(int g_no, int m_no, String content, String img_uri, int s_rate, int g_rate) {
		super();
		this.g_no = g_no;
		this.m_no = m_no;
		this.content = content;
		this.img_uri = img_uri;
		this.s_rate = s_rate;
		this.g_rate = g_rate;
	}

	public ReviewVO(int g_no, int m_no, String content) {
		super();
		this.g_no = g_no;
		this.m_no = m_no;
		this.content = content;
	}



	public ReviewVO(int r_no, int g_no, int m_no, String content, Date created_at, Date modified_at, int r_parent,
			int r_depth, int r_order) {
		super();
		this.r_no = r_no;
		this.g_no = g_no;
		this.m_no = m_no;
		this.content = content;
		this.created_at = created_at;
		this.modified_at = modified_at;
		this.r_parent = r_parent;
		this.r_depth = r_depth;
		this.r_order = r_order;
	}


	public ReviewVO(int r_no, int g_no, int m_no, String content, String img_uri, int s_rate, int g_rate,
			Date created_at, Date modified_at, int r_parent, int r_depth, int r_order) {
		super();
		this.r_no = r_no;
		this.g_no = g_no;
		this.m_no = m_no;
		this.content = content;
		this.img_uri = img_uri;
		this.s_rate = s_rate;
		this.g_rate = g_rate;
		this.created_at = created_at;
		this.modified_at = modified_at;
		this.r_parent = r_parent;
		this.r_depth = r_depth;
		this.r_order = r_order;
	}

	public int getR_no() {
		return r_no;
	}


	public void setR_no(int r_no) {
		this.r_no = r_no;
	}


	public int getG_no() {
		return g_no;
	}


	public void setG_no(int g_no) {
		this.g_no = g_no;
	}


	public int getM_no() {
		return m_no;
	}


	public void setM_no(int m_no) {
		this.m_no = m_no;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getImg_uri() {
		return img_uri;
	}


	public void setImg_uri(String img_uri) {
		this.img_uri = img_uri;
	}


	public int getS_rate() {
		return s_rate;
	}


	public void setS_rate(int s_rate) {
		this.s_rate = s_rate;
	}


	public int getG_rate() {
		return g_rate;
	}


	public void setG_rate(int g_rate) {
		this.g_rate = g_rate;
	}


	public Date getCreated_at() {
		return created_at;
	}


	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}


	public Date getModified_at() {
		return modified_at;
	}


	public void setModified_at(Date modified_at) {
		this.modified_at = modified_at;
	}


	public int getR_parent() {
		return r_parent;
	}


	public void setR_parent(int r_parent) {
		this.r_parent = r_parent;
	}


	public int getR_depth() {
		return r_depth;
	}


	public void setR_depth(int r_depth) {
		this.r_depth = r_depth;
	}


	public int getR_order() {
		return r_order;
	}


	public void setR_order(int r_order) {
		this.r_order = r_order;
	}


	@Override
	public String toString() {
		return "ReviewVO [r_no=" + r_no + ", g_no=" + g_no + ", m_no=" + m_no + ", content=" + content + ", img_uri="
				+ img_uri + ", s_rate=" + s_rate + ", g_rate=" + g_rate + ", created_at=" + created_at
				+ ", modified_at=" + modified_at + ", r_parent=" + r_parent + ", r_depth=" + r_depth + ", r_order="
				+ r_order + "]";
	}
	
	
}
