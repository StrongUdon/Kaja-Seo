package review;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Goods.GoodsVO;
import util.DBConn;

public class ReviewDAO implements ReviewIDAO{
	public static final int SLOW = 1;
	public static final int MEDIUM = 2;
	public static final int FAST = 3;
	private Connection con;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public ReviewDAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection();
	}

	@Override
	public boolean postReview(ReviewVO vo, int r_depth) {
		if(r_depth < 0) { //hidden값 상품평 순서로 -1이 들어오면 = 상품평 입력
			int depth = findMaxDepth(vo.getG_no());  //상품 번호로 상품평 순서를 구해라
			String sql = "INSERT INTO REVIEW"
					+ "(R_NO, G_NO, M_NO, CONTENT, IMG_URI"
					+ ", S_RATE, G_RATE, R_PARENT, R_DEPTH, R_ORDER)"
					+ " VALUES(REVIEW_INCREMENT.NEXTVAL, ?, ?, ?, ?, ?, ?, 0, ?, 1)";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, vo.getG_no());
				pstmt.setInt(2, vo.getM_no());
				pstmt.setString(3, vo.getContent());
				pstmt.setString(4, vo.getImg_uri());
				pstmt.setInt(5, vo.getS_rate());
				pstmt.setInt(6, vo.getG_rate());
				pstmt.setInt(7, depth);
				if(pstmt.executeUpdate()==1) {
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("새로운 상품평 등록 실패");
			}
			return false;
		} else { //r_depth값이 들어오면 = 상품평 순서 = 댓글 입력
			int order = findMaxOrder(vo.getG_no(), r_depth); //댓글 순서 구하기
			int parent = findParent(vo.getG_no(), r_depth); //댓글의 상품평번호 구하기
			vo.setR_depth(r_depth); //상품평 순서
			vo.setR_order(order); //상품평 댓글 순서
			vo.setR_parent(parent); //댓글의 상품평 번호
			System.out.println("달리는 댓글의 상품평 번호: " + parent 
					+ "상품평 순서: " + r_depth + "댓글 순서: " + order );
			String sql1 = "INSERT INTO REVIEW"
					+ "(R_NO, G_NO, M_NO, CONTENT"
					+ ", R_PARENT, R_DEPTH, R_ORDER)"
					+ " VALUES(REVIEW_INCREMENT.NEXTVAL, ?, ?, ?, ?, ?, ?)";
			try {
				pstmt = con.prepareStatement(sql1);
				pstmt.setInt(1, vo.getG_no());
				pstmt.setInt(2, vo.getM_no());
				pstmt.setString(3, vo.getContent());
				pstmt.setInt(4, vo.getR_parent());
				pstmt.setInt(5, vo.getR_depth());
				pstmt.setInt(6, vo.getR_order());
				if(pstmt.executeUpdate()==1) {
					return true;
				}
			} catch (SQLException e) {
				System.out.println();
				e.printStackTrace();
				System.out.println("상품평 댓글 등록 실패");
			}
		}
		return false; 
		
	}

	private int findParent(int g_no, int r_depth) {
		String sql = "SELECT R_NO FROM REVIEW"
				+ " WHERE G_NO = ?"
				+ " AND R_DEPTH = ?"
				+ " AND R_ORDER = 1"; //R_ORDER=1 상품평이라는 말
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			pstmt.setInt(2, r_depth);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				int parent = rs.getInt("r_no");
				return parent;
			}
		} catch (SQLException e) {
			System.out.println("Error in findParent");
			e.printStackTrace();
		}
		return -1;
	}

	private int findMaxOrder(int g_no, int r_depth) { //댓글 순서 구하기
		String sql = "SELECT MAX(R_ORDER)+1"
				+ " FROM REVIEW"
				+ " WHERE G_NO = ?"
				+ " AND R_DEPTH = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			pstmt.setInt(2, r_depth);
			System.out.println(g_no + " " + r_depth);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				int order = rs.getInt("MAX(R_ORDER)+1");
				return order;
			}else {
				System.out.println("Error in findReplyByORDER");
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

	private int findMaxDepth(int g_no) { //상품 번호로 상품평 순서 구하기
		String sql = "SELECT MAX(R_DEPTH)+1"
				+ " FROM REVIEW"
				+ " WHERE G_NO = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				int depth = rs.getInt("MAX(R_DEPTH)+1"); //첫번째 상품평이면 0반환
				System.out.println(depth + "findMaxDepth");
				return depth;
			}else {
				System.out.println("Error in findReplyByDepth");
				return -1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public boolean editReview(ReviewVO vo) { 
		String sql = "UPDATE REVIEW"
				+ " SET CONTENT = ?"
				+ " WHERE R_NO = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vo.getContent());
			pstmt.setInt(2, vo.getR_no());
			if(pstmt.executeUpdate()==1) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Error in editReply");
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteReview(ReviewVO vo) {
		String sql = "DELETE FROM REVIEW"
				+ " WHERE R_NO = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, vo.getR_no());
			if(pstmt.executeUpdate()==1) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Error in deleteReply");
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<ReviewVO> findReviewsByGoods(int goods_no) {
		String sql = "SELECT * FROM REVIEW"
				+ " WHERE G_NO = ?"
				//+ " ORDER BY R_DEPTH, R_ORDER"
					+ " ORDER BY R_DEPTH DESC, R_ORDER ASC"; 
					//상품평 최신 것이 먼저, 대댓글은 먼저 등록된 것 부터
		List<ReviewVO> rList = new ArrayList<>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, goods_no);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				rList.add(new ReviewVO(
						rs.getInt("r_no"),
						rs.getInt("g_no"),
						rs.getInt("m_no"),
						rs.getString("content"),
						rs.getString("img_uri"),
						rs.getInt("s_rate"),
						rs.getInt("g_rate"),
						rs.getDate("created_at"),
						rs.getDate("modified_at"),
						rs.getInt("r_parent"),
						rs.getInt("r_depth"),
						rs.getInt("r_order")
						));
			}
			return rList;
		} catch (SQLException e) {
			System.out.println("Error in findRepliesByGoods");
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<ReviewVO> findReviewsByMember(int member_no) {
		String sql = "SELECT * FROM REVIEW"
				+ " WHERE M_NO = ?"
				+ " ORDER BY CREATED_AT DESC";
		List<ReviewVO> rList = new ArrayList<>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, member_no);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				rList.add(new ReviewVO(
						rs.getInt("r_no"),
						rs.getInt("g_no"),
						rs.getInt("m_no"),
						rs.getString("content"),
						rs.getString("img_uri"),
						rs.getInt("s_rate"),
						rs.getInt("g_rate"),
						rs.getDate("created_at"),
						rs.getDate("modified_at"),
						rs.getInt("r_parent"),
						rs.getInt("r_depth"),
						rs.getInt("r_order")
						));
			}
		} catch (SQLException e) {
			System.out.println("Error in findRepliesByMember");
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public int count(int g_no) { //없으면 -1을 반환
		String sql = "SELECT COUNT(*)"
				+ " FROM REVIEW"
				+ " WHERE G_NO = ?";
		int cnt = -1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			rs = pstmt.executeQuery();
			cnt = rs.getInt("COUNT(*)");
		} catch (SQLException e) {
			System.out.println("Error in count");
			e.printStackTrace();
		}
		
		return cnt;
	}

	@Override
	public List<ReviewVO> findRepliesByGoods(int goods_no) {
		String sql = "SELECT * FROM REVIEW"
				+ " WHERE G_NO = ?"
				+ " ORDER BY R_DEPTH, R_ORDER"; 
					//+ " ORDER BY R_DEPTH DESC, R_ORDER ASC"; 
					//상품평 최신 것이 먼저, 대댓글은 먼저 등록된 것 부터
		List<ReviewVO> rList = new ArrayList<>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, goods_no);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				rList.add(new ReviewVO(
						rs.getInt("r_no"),
						rs.getInt("g_no"),
						rs.getInt("m_no"),
						rs.getString("content"),
						rs.getDate("created_at"),
						rs.getDate("modified_at"),
						rs.getInt("r_parent"),
						rs.getInt("r_depth"),
						rs.getInt("r_order")
						));
			}
			return rList;
		} catch (SQLException e) {
			System.out.println("Error in findRepliesByGoods");
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public int calGoodsRate(int goods_no) {
		
		return 0;
	}

	@Override
	public int calShippingRate(int goods_no) {
		// TODO Auto-generated method stub
		return 0;
	}


	
	
}
