package review;

import java.util.List;

import Goods.GoodsVO;

public interface ReviewIDAO {
	
	boolean postReview(ReviewVO vo, int re_depth);
	// 상품평 달기
	boolean editReview(ReviewVO vo);
	// 상품평 수정
	boolean deleteReview(ReviewVO vo);
	// 상품평 삭제
	List<ReviewVO> findReviewsByGoods(int goods_no);
	//상품번호로 상품평 찾기
	List<ReviewVO> findRepliesByGoods(int goods_no);
	//상품번호로 상품평의 댓글 찾기
	List<ReviewVO> findReviewsByMember(int member_no);
	//멤버넘버로 상품평 찾기
	public int count(int g_no);
	//상품번호로 상품평 개수 찾기
	int calGoodsRate(int goods_no);
	//상품번호로 상품평 평점 구하기
	int calShippingRate(int goods_no);
	//상품번호로 배송 속도 평점 구하기
	
}
