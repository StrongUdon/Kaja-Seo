package message;

import java.sql.*;
import java.sql.Date;
import java.util.*;

import util.DBConn;

public class MessageDAO implements MessageIDAO{
	
	private Connection con;
	
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	
	public MessageDAO() throws ClassNotFoundException, SQLException {
		con=new DBConn().getConnection();
	}
	
	
	
	@Override
	public boolean send(MessageVO msg) {
		String sql="INSERT INTO MESSAGE(message_no, sender, receiver, send_date, title, content, is_notice, is_read) "
				+ " VALUES(message_increment.nextval, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, msg.getSender());
			pstmt.setString(2, msg.getReceiver());
			pstmt.setString(3, msg.getSend_date());
			pstmt.setString(4, msg.getTitle());
			pstmt.setString(5, msg.getContent());
			pstmt.setBoolean(6, msg.isIs_notice());
			pstmt.setBoolean(7, msg.isIs_read());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Send Exception");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public boolean del_message(int message_no) {
		String sql="DELETE FROM MESSAGE WHERE MESSAGE_NO = ?";
		
			try {
				pstmt=con.prepareStatement(sql);
				pstmt.setInt(1, message_no);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}			
		
		return true;
		
	}

	@Override
	public MessageVO getContent(int message_no) {
		String sql="SELECT * FROM MESSAGE WHERE MESSAGE_NO = ?";
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, message_no);
			rs=pstmt.executeQuery();
			MessageVO mv=new MessageVO();
			if(rs.next()) {
				String sender = rs.getString("sender");
				String receiver = rs.getString("receiver");
				String send_date = rs.getString("send_date");
				String title = rs.getString("title");
				String content = rs.getString("content");
				boolean is_notice = rs.getBoolean("is_notice");
				boolean is_read = rs.getBoolean("is_read");
				
				mv = new MessageVO(message_no, sender, receiver, send_date, title, content, is_notice, is_read);
			}
			return mv;
		} catch (SQLException e) {
			System.out.println("Error");
			e.printStackTrace();
		}
		return null;
	}
	


	@Override
	public ArrayList<MessageVO> getContentList(String receiver) {
		System.out.println("이거는 dao에서 받는 reciver : "+receiver);
		ArrayList<MessageVO> message_list = new ArrayList<>();
		String sql="SELECT * FROM MESSAGE where receiver = ? ORDER BY SEND_DATE DESC";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, receiver);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				int message_no = rs.getInt("message_no");
				String sender = rs.getString("sender");
				receiver = rs.getString("receiver");
				String send_date = rs.getString("send_date");
				String title = rs.getString("title");
				String content = rs.getString("content");
				boolean is_notice = rs.getBoolean("is_notice");
				boolean is_read = rs.getBoolean("is_read");
				
				
				MessageVO msgVO = new MessageVO(message_no, sender, receiver, send_date, title, content, is_notice, is_read);
				System.out.println("DAO : "+ msgVO);
				
				message_list.add(msgVO);
				
			}
			return message_list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}



	@Override
	public ArrayList<MessageVO> getSendContentList(String sender) {
		System.out.println("이거는 dao에서 받는 sender : "+sender);
		ArrayList<MessageVO> message_list1 = new ArrayList<>();
		String sql="SELECT * FROM MESSAGE where sender = ? ORDER BY SEND_DATE DESC";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, sender);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				int message_no = rs.getInt("message_no");
				sender = rs.getString("sender");
				String receiver = rs.getString("receiver");
				String send_date = rs.getString("send_date");
				String title = rs.getString("title");
				String content = rs.getString("content");
				boolean is_notice = rs.getBoolean("is_notice");
				boolean is_read = rs.getBoolean("is_read");
								
				MessageVO msgVO = new MessageVO(message_no, sender, receiver, send_date, title, content, is_notice, is_read);
				message_list1.add(msgVO);
			}
			return message_list1;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	@Override
	   public boolean is_read(int message_no) {
	      String sql = "update MESSAGE set is_read = 1 where message_no = ?";
	         try {
	            pstmt = con.prepareStatement(sql);
	            pstmt.setInt(1, message_no);
	            pstmt.executeUpdate();
	            System.out.println("안읽음 -> 읽음!");
	         } catch (SQLException e) {
	            System.out.println("Update Exception");
	            return false;
	         }
	         return true;
	   }


}
