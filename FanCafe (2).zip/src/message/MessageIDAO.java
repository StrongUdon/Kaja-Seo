package message;

import java.util.ArrayList;

public interface MessageIDAO {
   
   public boolean send(MessageVO msg); 
   //전송 (발신인 m_no, 수신인 m_name 받아서 전송 성공/실패 반환)
   //(발신인 m_no 체크, 수신인 m_name이 존재하는지 체크)*/
   
   
   public boolean del_message(int message_no);
   //삭제 (쪽지번호 message_no를 받아서 삭제 성공/실패 반환)
   //삭제된 쪽지는 다시 볼 수 없음 (휴지통 X)
   //쪽지 삭제후 message_no 재정렬? 그대로?
   
   
   public MessageVO getContent(int message_no); 
   //쪽지 제목 또는 내용부분 클릭해서 상세 내용 읽기
   //message_no 받아 MessageVO 반환
   
   
   public ArrayList<MessageVO> getContentList(String receiver);
   //한사람이 받은 쪽지 전체 목록 반환 (쪽지 발송 시간순으로 나열-최근 쪽지가 가장 위에)

   public ArrayList<MessageVO> getSendContentList(String sender);
   //보낸 메시지함 출력
   
   public boolean is_read(int message_no);
   // 메세지 번호 받아서 읽음/안읽음 수정 
   
 
}