package message;


import java.util.Date;

/*  MESSAGE_NO INTEGER,
  SENDER INTEGER NOT NULL,
  RECEIVER VARCHAR2(20) NOT NULL,
  SEND_DATE DATE NOT NULL,
  TITLE VARCHAR2(20),
  CONTENT VARCHAR2(500) NOT NULL,
  IS_NOTICE CHAR(1),
  IS_READ CHAR(1),
  CONSTRAINT MESSAGE_PK PRIMARY KEY(MESSAGE_NO),
  CONSTRAINT MESSAGE_SENDER_FK FOREIGN KEY (SENDER) REFERENCES MEMBERS(M_NO),
  CONSTRAINT MESSAGE_RECEIVER_FK FOREIGN KEY (RECEIVER) REFERENCES MEMBERS(M_NAME),
  CONSTRAINT MESSAGE_NOTICE_FK FOREIGN KEY (IS_NOTICE) REFERENCES MEMBERS(IS_ADMIN),
  CONSTRAINT MESSAGE_READ_FK FOREIGN KEY (IS_READ) REFERENCES MEMBERS(IS_SNS)*/

public class MessageVO {
   private int message_no;
   private String sender;
   private String receiver;
   private String send_date;
   private String title;
   private String content;
   
   private boolean is_notice;    
   private boolean is_read;

   public MessageVO() {
      // TODO Auto-generated constructor stub
   }

   public MessageVO(int message_no, String sender, String receiver, String send_date, String title, String content,
         boolean is_notice, boolean is_read) {
      super();
      this.message_no = message_no;
      this.sender = sender;
      this.receiver = receiver;
      this.send_date = send_date;
      this.title = title;
      this.content = content;
      this.is_notice = is_notice;
      this.is_read = is_read;
   }

   public int getMessage_no() {
      return message_no;
   }

   public void setMessage_no(int message_no) {
      this.message_no = message_no;
   }

   public String getSender() {
      return sender;
   }

   public void setSender(String sender) {
      this.sender = sender;
   }

   public String getReceiver() {
      return receiver;
   }

   public void setReceiver(String receiver) {
      this.receiver = receiver;
   }

   public String getSend_date() {
      return send_date;
   }

   public void setSend_date(String send_date) {
      this.send_date = send_date;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public String getContent() {
      return content;
   }

   public void setContent(String content) {
      this.content = content;
   }

   public boolean isIs_notice() {
      return is_notice;
   }

   public void setIs_notice(boolean is_notice) {
      this.is_notice = is_notice;
   }

   public boolean isIs_read() {
      return is_read;
   }

   public void setIs_read(boolean is_read) {
      this.is_read = is_read;
   }

   @Override
   public String toString() {
      return "MessageVO [message_no=" + message_no + ", sender=" + sender + ", receiver=" + receiver + ", send_date="
            + send_date + ", title=" + title + ", content=" + content + ", is_notice=" + is_notice + ", is_read="
            + is_read + "]";
   }
   
   

}