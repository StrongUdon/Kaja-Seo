package calendar;

import java.util.Date;

public class CalendarVO {

	private int cal_no;
	private int m_no;
	private String title;
	private String start_date;
	private String end_date;
	private String bg_color;
	private String detail;
	
	public CalendarVO() {
		// TODO Auto-generated constructor stub
	}

	public CalendarVO(int cal_no, int m_no, String title, String start_date, String end_date, String bg_color,
			String detail) {
		super();
		this.cal_no = cal_no;
		this.m_no = m_no;
		this.title = title;
		this.start_date = start_date;
		this.end_date = end_date;
		this.bg_color = bg_color;
		this.detail = detail;
	}

	public int getCal_no() {
		return cal_no;
	}

	public void setCal_no(int cal_no) {
		this.cal_no = cal_no;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getBg_color() {
		return bg_color;
	}

	public void setBg_color(String bg_color) {
		this.bg_color = bg_color;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	@Override
	public String toString() {
		return "CalendarVO [cal_no=" + cal_no + ", m_no=" + m_no + ", title=" + title + ", start_date="
				+ start_date + ", end_date=" + end_date + ", bg_color=" + bg_color + ", detail=" + detail + "]";
	}
	
	

}
