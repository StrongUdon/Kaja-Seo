package calendar;

import java.sql.SQLException;
import java.util.ArrayList;

public interface CalendarIDAO {

	public ArrayList<CalendarVO> getAllInfo() throws SQLException;
	// 전체 리스트 출력

	public CalendarVO getOneInfo(int member_no) throws SQLException;
	// member_no 받아서 하나의 일정 출력

	public boolean insert(CalendarVO cvo) throws SQLException;
	// 일정 추가

	public boolean change_info(int cal_no, String title, String start_date, String end_date, String bg_color,
			String detail);
	// 일정 수정

	public boolean delete(int cal_no);
	// 일정 삭제

	
	
}