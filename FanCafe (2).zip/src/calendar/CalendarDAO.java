package calendar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBConn;

public class CalendarDAO implements CalendarIDAO {

	private Connection con; // MemberConn

	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public CalendarDAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection();
		
	}

	public ArrayList<CalendarVO> getAllInfo() throws SQLException {

		ArrayList<CalendarVO> ev_list = new ArrayList<>();
		String sql = "select * from calendar order by m_no";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while (rs.next()) {

			int cal_no = rs.getInt("cal_no");
			int m_no = rs.getInt("m_no");
			String title = rs.getString("title");
			String start_date = rs.getString("start_date");
			String end_date = end_date_plus(rs.getString("end_date").split("-"));		
			String bg_color = rs.getString("bg_color");
			String detail = rs.getString("detail");

			CalendarVO cv = new CalendarVO(cal_no, m_no, title, start_date, end_date, bg_color, detail);

			ev_list.add(cv);
		}
		return ev_list;
	}

	private String end_date_plus(String[] end_list){
	// 일정의 직관성을 위해 임의로 DB에서 select해서 날짜에 +1 해주는 메서드
		
		int y = Integer.parseInt(end_list[0]);
		int m = Integer.parseInt(end_list[1]);
		int d = Integer.parseInt(end_list[2].split(" ")[0]) + 1;

		switch (d) {
		case 29:case 30:
			if (m == 2) {
				if (y % 4 == 0) {
					d = d - 29;
				} else {
					d = d - 28;
				}
				m++;
			}
			break;
		case 31:
			if (m == 4 || m == 6 || m == 9 || m == 11) {
				d = d - 30;
				m++;
			}
			break;
		case 32:
			if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) {
				d = d - 31;
				m++;
			} 
			break;
		}
		if(m==13) {
			m = m-12;
			y++;
		}
		return y+"-"+m+"-"+d+" "+"00:00:00";
	}

	public CalendarVO getOneInfo(int m_no) throws SQLException {

		CalendarVO cv = new CalendarVO();
		String sql = "select * from calendar where m_no = ?";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		pstmt.setInt(1, m_no);
		while (rs.next()) {
			int cal_no = rs.getInt("cal_no");
			String title = rs.getString("title");
			String start_date = rs.getString("start_date");
			String end_date = rs.getString("end_date");
			String bg_color = rs.getString("bg_color");
			String detail = rs.getString("detail");

			cv = new CalendarVO(cal_no, m_no, title, start_date, end_date, bg_color, detail);

		}
		return cv;

	}

	@Override
	public boolean insert(CalendarVO cvo) throws SQLException {

		String sql = "insert into calendar values (CAL_INCREMENT.nextval, ?, ?, ?, ?, ?, ?)";

		pstmt = con.prepareStatement(sql);

		pstmt.setInt(1, cvo.getM_no());
		pstmt.setString(2, cvo.getTitle());
		pstmt.setString(3, cvo.getStart_date());
		pstmt.setString(4, cvo.getEnd_date());
		pstmt.setString(5, cvo.getBg_color());
		pstmt.setString(6, cvo.getDetail());

		if (pstmt.executeUpdate() == 0) {
			System.out.println("안된거 같은데");
			return false;
		} else {
			System.out.println("성공");
			return true;
		}

	}

	public boolean delete(int cal_no) {
		String sql = "delete from calendar where cal_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, cal_no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Delete Exception");
			return false;
		}
		return true;
	}

	public boolean change_info(int cal_no, String title, String start_date, String end_date, String bg_color,
			String detail) {

		String sql = "update calendar set title = ?, start_date = ?, end_date = ?, bg_color = ?, detail = ? where cal_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, start_date);
			pstmt.setString(3, end_date);
			pstmt.setString(4, bg_color);
			pstmt.setString(5, detail);
			pstmt.setInt(6, cal_no);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("Update Exception");
			return false;
		}
		return true;
	}

}
