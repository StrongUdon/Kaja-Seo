package Goods;

import java.sql.SQLException;
import java.util.ArrayList;

public interface GoodsIDAO {
	public ArrayList<GoodsVO> getAllGoods() throws SQLException;
	
	public GoodsVO searchDetail(int no) throws SQLException;
	
	public ArrayList<GoodsVO> orderBySold() throws SQLException;
	
	public int min_val() throws SQLException;
	
	public String checkFee(int totPrice) throws SQLException;
	
	public boolean insert_wish(int g_no, int m_no) throws SQLException;
	
	public ArrayList<Integer> count_wish() throws SQLException;
	
	public int count_wish(int g_no) throws SQLException;
	
	public boolean delete_wish(int g_no, int m_no) throws SQLException;
	
	public ArrayList<Integer> orderBySold_Wish() throws SQLException;
	
	public ArrayList<Integer> find_wishList(int m_no) throws SQLException;
	
	public int count_goods(int m_no) throws SQLException;
}
