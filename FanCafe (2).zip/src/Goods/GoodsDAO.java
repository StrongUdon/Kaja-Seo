package Goods;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Goods.GoodsVO;
import util.DBConn;


public class GoodsDAO implements GoodsIDAO{
	private Connection con;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public GoodsDAO()  
			throws ClassNotFoundException, SQLException{
		con= new DBConn().getConnection();
	}
	public void pstmtClose() throws SQLException{
		if(pstmt != null){ pstmt.close(); }
	}

	public void getAllInfoClose() throws SQLException{
		if(rs != null){ rs.close(); }
		if(pstmt != null){ pstmt.close(); }
		if(con != null){ con.close(); }
	}
	
	public ArrayList<GoodsVO> getAllGoods()  
			throws SQLException{//////
		ArrayList<GoodsVO> list
		               = new ArrayList<GoodsVO>();
		String sql 
		= "SELECT * FROM Goods"
				+ " ORDER BY G_NO";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()){
			int g_no = rs.getInt("g_no");
			String g_name = rs.getString("g_name");
			String detail = rs.getString("detail");
			String img_uri = rs.getString("img_uri");
			int price = rs.getInt("price");
			int g_left = rs.getInt("g_left");
			int g_sold = rs.getInt("g_sold");
			
			GoodsVO gv = new GoodsVO(g_no,g_name,detail,img_uri,price,g_left,g_sold);
			list.add(gv);
		}
		return list;
	}
	
	public GoodsVO searchDetail(int no) throws SQLException {
		GoodsVO gv;
		String sql = "SELECT * FROM Goods where g_no=?";
		// ? : 원하는 사람 이름
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, no);
		rs = pstmt.executeQuery();//
		if (rs.next()) {
			int g_no = rs.getInt("g_no");
			String g_name = rs.getString("g_name");
			String detail = rs.getString("detail");
			String img_uri = rs.getString("img_uri");
			int price = rs.getInt("price");
			int g_left = rs.getInt("g_left");
			int g_sold = rs.getInt("g_sold");
			gv = new GoodsVO(g_no,g_name,detail,img_uri,price,g_left,g_sold);
		} else { 
			gv = null; 
			System.out.println("Failed to search Goods detail");
		}
		return gv;
	}
	
	
	public ArrayList<GoodsVO> orderBySold()  
			throws SQLException{//////
		ArrayList<GoodsVO> list
		               = new ArrayList<GoodsVO>();
		String sql 
		= "SELECT * FROM Goods"
				+ " WHERE ROWNUM <= 3"
				+ " ORDER BY G_SOLD DESC";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()){
			int g_no = rs.getInt("g_no");
			String g_name = rs.getString("g_name");
			String detail = rs.getString("detail");
			String img_uri = rs.getString("img_uri");
			int price = rs.getInt("price");
			int g_left = rs.getInt("g_left");
			int g_sold = rs.getInt("g_sold");
			
			GoodsVO gv = new GoodsVO(g_no,g_name,detail,img_uri,price,g_left,g_sold);
			list.add(gv);
		}
		return list;
	}

	
	
	public int min_val() throws SQLException {
		int min_val=0;
		String sql 
		= "SELECT MIN_VAL FROM shipping_fee";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()){
			min_val = rs.getInt("min_val");
		}
		return min_val;
	}
	
	public String checkFee(int totPrice) throws SQLException {
		String fee;
		String sql = "SELECT LABEL FROM SHIPPING_FEE WHERE MIN_VAL<=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, totPrice);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			fee = rs.getString("label");
			System.out.println("결과: 배송비 무료");
		}else {
			fee = "조건부무료";
			System.out.println("결과: 조건부 무료");
		}
		return fee;
	}
	
	public boolean insert_wish(int g_no, int m_no) {
		String sql = " INSERT INTO WISHLIST VALUES(?,?) ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			pstmt.setInt(2, m_no);
			
			if (pstmt.executeUpdate() == 1) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Insert Exception");
			e.printStackTrace();
		}
		
		return false;
	}
	
	public ArrayList<Integer> count_wish() throws SQLException { //모든 상품 당 찜 개수 출력
		
		ArrayList<Integer> wishList = new ArrayList<>();
		String sql = "select count(m_no) from wishlist w, goods g"
				+ " where w.g_no(+) = g.g_no"
				+ " GROUP BY g.g_no"
				+ " order by g.g_no";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()){
			int count_wish = rs.getInt(1);
			wishList.add(count_wish);
		} 
		return wishList;
	}
	
	public int count_wish(int g_no) throws SQLException { //한 상품 당 찜 개수 출력
		/*ArrayList<Integer> wishList = new ArrayList<>();*/
		String sql = "select count(m_no) from wishlist w, goods g"
				+ " where w.g_no(+) = g.g_no"
				+ " and g.g_no = ?"
				+ " GROUP BY g.g_no"
				+ " order by g.g_no";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, g_no);
		rs = pstmt.executeQuery();
		if (rs.next()) {
			int count_wish = rs.getInt(1);
			return count_wish;
		} 
		//return wishList;
		else {
			return 0;
		}
	}
	
	public boolean delete_wish(int g_no, int m_no) {
		String sql = "delete from wishlist where g_no=? and m_no=?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			pstmt.setInt(2, m_no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("delete Exception");
			return false;
		}
		return true;
	}
	
	
	public ArrayList<Integer> orderBySold_Wish()  
			throws SQLException{ // 판매량(인기) 순으로 정렬시 찜 개수 리스트 row = 3
		ArrayList<Integer> wishList
		               = new ArrayList<Integer>();
		String sql 
		= "SELECT * FROM(" 
				+ " select count(m_no)" 
				+ " from goods g, wishlist w" 
				+ " where w.g_no(+) = g.g_no" 
				+ " group by g.g_no, g_sold" 
				+ " order by g_sold desc" 
				+ ")" 
				+ " WHERE ROWNUM <= 3";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()){
			int count_wish = rs.getInt(1);
			wishList.add(count_wish);
		}
		return wishList;
	}
	
	public ArrayList<Integer> find_wishList(int m_no) throws 
			SQLException{ // user가 찜한 상품 리스트
		ArrayList<Integer> wishList
        				= new ArrayList<Integer>();
		String sql 
		= "SELECT W.M_NO, G.G_NO"
				+ " FROM GOODS G, WISHLIST W"
				+ " WHERE W.G_NO(+) = G.G_NO"
				+ " AND W.M_NO = ?"
				+ " GROUP BY G.G_NO, W.M_NO";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, m_no);
		rs = pstmt.executeQuery();
		while(rs.next()){
			int g_no = rs.getInt("g_no");
			wishList.add(g_no);
		}
		return wishList;
	}
	
	public int count_goods(int m_no) throws SQLException { //user가 찜한 상품 개수
		int cnt = 0;
		String sql 
		= "SELECT COUNT(G_NO)"
				+ " FROM WISHLIST"
				+ " WHERE M_NO = ?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, m_no);
		rs = pstmt.executeQuery();
		while(rs.next()){
			cnt = rs.getInt("COUNT(G_NO)");
		}
		return cnt;
	}
	
	 
	   public int count_eachwish(int g_no) throws SQLException { //하나상품의 찜 개수 출력
	   
	      String sql = "select count(m_no) from wishlist where g_no = ?";

	      pstmt = con.prepareStatement(sql);
	      pstmt.setInt(1, g_no);
	      rs = pstmt.executeQuery();
	      if(rs.next()) {
	         return rs.getInt(1);
	      }else {
	      return 0;
	      }
	   }
	   
	   public boolean iswish(int g_no, int m_no) throws SQLException{
		      
		      String sql = "SELECT * FROM wishlist where g_no = ? and m_no = ? " ;
		      pstmt = con.prepareStatement(sql);
		      pstmt.setInt(1, g_no);
		      pstmt.setInt(2, m_no);
		      rs = pstmt.executeQuery();
		      if (rs.next()) {
		         return false; 
		      }else {
		         return true;    
		      }
		   }   // 이미 들어 있으면  false 없으면 true 
	
		public String searchname(int g_no) throws SQLException {
			String g_name = null;
			String sql = "SELECT * FROM Goods where g_no=?";
			// ? : 원하는 사람 이름
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			rs = pstmt.executeQuery();//
			if (rs.next()) {
				g_name = rs.getString("g_name");

			} else { 
				 
				System.out.println("Failed to search Goods name");
			}
			System.out.println("찾았어 : " + g_name);
			return g_name;
		}
	   
		public int avg_rate(int g_no) throws SQLException {
			int avg_rate = 0;
			String sql = "SELECT round(avg(g_rate),1) from review  where g_no=?";
			// ? : 원하는 사람 이름
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, g_no);
			rs = pstmt.executeQuery();//
			if (rs.next()) {
				avg_rate = rs.getInt("round(avg(g_rate),1)");

			} else { 
				System.out.println("Failed to average Rate");
			}
			System.out.println("상품 총 평점: " + avg_rate);
			return avg_rate;
		}
	   
		public boolean add_goods(String g_name, String detail, String img_uri, int price, int g_left, int g_sold) {
			String sql = "INSERT INTO GOODS"
					+ "(G_NO, G_NAME, DETAIL, IMG_URI, PRICE"
					+ ", G_LEFT, G_SOLD)"
					+ " VALUES(GOODS_INCREMENT.NEXTVAL, ?, ?, ?, ?, ?, ?)";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, g_name);
				pstmt.setString(2, detail);
				pstmt.setString(3, img_uri);
				pstmt.setInt(4, price);
				pstmt.setInt(5, g_left);
				pstmt.setInt(6, g_sold);
				if(pstmt.executeUpdate()==1) {
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("새로운 굿즈 등록 실패");
			}
			
			return false;
		}
	   
		public boolean updatestock(int g_no) throws SQLException {
	         
	         int sw =0; int sw1 = 0;
	         
	         String sql1 = "update goods set g_sold = g_sold + 1" 
	               +" where g_no = ?";
	         String sql2 = "update goods set g_left = g_left - 1"
	               +" where g_no = ?";
	         
	         pstmt = con.prepareStatement(sql1);
	         pstmt.setInt(1, g_no);
	         
	         if (pstmt.executeUpdate() ==1) {
	            sw =1;
	            System.out.println("1번 업뎃 성공");
	         }
	         pstmt = con.prepareStatement(sql2);
	         pstmt.setInt(1, g_no);
	         
	         if (pstmt.executeUpdate() ==1) {
	            sw1 =1;
	            System.out.println("2번 업뎃 성공");
	         }
	         if (sw == 1 && sw1 ==1)
	            return true;
	         
	         
	         return false;
	      }
		
public boolean delete(int g_no) throws SQLException {
			
			String sql = "delete from goods where g_no = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,g_no);
			if (pstmt.executeUpdate() ==1) {
				System.out.println("삭제 성공");
				return true;
			}
			System.out.println("삭제 실패");
			return false;
		}
	
		
		public boolean update(int g_no, String g_name, String detail, String img_uri, int price) throws SQLException {

			String sql = "update goods set g_name =?, detail = ?, img_uri = ? price = ?"
					+ "where g_no = ? ";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, g_name);
			pstmt.setString(2, detail);
			pstmt.setString(3, img_uri);
			pstmt.setInt(4, price);
			pstmt.setInt(5, g_no);
			
			if (pstmt.executeUpdate() == 1) {
				
				System.out.println("굿즈 업데이트 성공");
				return true;
			}
			System.out.println("굿즈 업데이트 실패");
			return false;
		}
}





