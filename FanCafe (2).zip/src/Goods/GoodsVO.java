package Goods;

public class GoodsVO {
	private int g_no;
	private String g_name;
	private String detail;
	private String img_uri;
	private int price;
	private int g_left;
	private int g_sold;
	

	public GoodsVO(int g_no, String g_name, String detail, String img_uri, int price, int g_left, int g_sold) {
		super();
		this.g_no = g_no;
		this.g_name = g_name;
		this.detail = detail;
		this.img_uri = img_uri;
		this.price = price;
		this.g_left = g_left;
		this.g_sold = g_sold;
	}
	
	public GoodsVO() {}



	public int getG_no() {
		return g_no;
	}
	public void setG_no(int g_no) {
		this.g_no = g_no;
	}
	public String getG_name() {
		return g_name;
	}
	public void setG_name(String g_name) {
		this.g_name = g_name;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getImg_uri() {
		return img_uri;
	}
	public void setImg_uri(String img_uri) {
		this.img_uri = img_uri;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getG_left() {
		return g_left;
	}
	public void setG_left(int g_left) {
		this.g_left = g_left;
	}
	public int getG_sold() {
		return g_sold;
	}
	public void setG_sold(int g_sold) {
		this.g_sold = g_sold;
	}
	@Override
	public String toString() {
		return "" + g_no;
	}

}