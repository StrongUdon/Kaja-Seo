package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConn;

public class BoardDAO implements BoardIDAO {
	private Connection con; // MemberConn

	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public BoardDAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection();
				
	}

	@Override
	public boolean addBoard(BoardVO bvo) {
		String sql  = "INSERT INTO BOARDS ("
				+ " B_NO, B_NAME, DETAIL) "
				+ " VALUES (BOARD_INCREMENT.NEXTVAL, ?, ?)";
		
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, bvo.getB_name());
				pstmt.setString(2, bvo.getDetail());
				
				if(pstmt.executeUpdate() == 1) {
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return false;
	}

	@Override
	public List<BoardVO> boardList() {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		String sql = "SELECT * FROM BOARDS ";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				boardList.add(new BoardVO(rs.getInt("b_no"),
								rs.getString("b_name"),
								rs.getString("detail")));
			}
			return boardList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}
	@Override
	public boolean update(BoardVO bvo) {

		String sql = " update boards set b_name = ? , detail = ? where b_no = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bvo.getB_name());
			pstmt.setString(2, bvo.getDetail());
			pstmt.setInt(3, bvo.getB_no());			
			if (pstmt.executeUpdate() ==1) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Update Exception");
			e.printStackTrace();
		}
		return false;
		
	}
	@Override
	public BoardVO findBoard(int b_no) {
		String sql = " SELECT * FROM BOARDS "
				+ " WHERE B_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return new BoardVO(rs.getInt("b_no"),
								rs.getString("b_name"),
								rs.getString("detail"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}

	@Override
	public boolean deleteBoard(int b_no) {
		String sql = "DELETE FROM BOARDS "
				+ "WHERE B_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			if(pstmt.executeUpdate() == 1) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
