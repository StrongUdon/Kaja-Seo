package board;

public class BoardVO {
	private int b_no;
	private String b_name;
	private String detail;
	public BoardVO(int b_no, String b_name, String detail) {
		super();
		this.b_no = b_no;
		this.b_name = b_name;
		this.detail = detail;
	}
	
	
	public BoardVO(String b_name, String detail) {
		super();
		this.b_name = b_name;
		this.detail = detail;
	}


	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	@Override
	public String toString() {
		return "BoardVO [b_no=" + b_no + ", b_name=" + b_name + ", detail=" + detail + "]";
	}
	
}
