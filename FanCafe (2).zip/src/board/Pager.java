package board;

public class Pager {
	public static final int MAX_INDEX = 5;
	private int curr; //현재 페이지 인덱스
	private int pre; 
	private int next;
	private int blockSize; //페이지당 게시글 수
	private int totCnt; //게시판당 총 게시물 수
	private int totBlock;//
	private int rowStart;
	private int rowEnd;
	
	
	public Pager(int blockSize, int totCnt) {
		super();
		this.blockSize = blockSize;
		this.totCnt = totCnt;		
		setTotBlock();
		setCurr(1);
		setRow();
	}
	public boolean fastForward() {
		if(curr > 5) {
			return setCurr(curr - 5);
		} else {
			return setCurr(1);
		}
	}
	public boolean fastBackward() {
		if((curr+5) <= totBlock) {
			return setCurr(curr + 5);
		} else {
			return setCurr(totBlock);
		}
		
	}
	public boolean forward() {
		if(curr < totBlock) {	
			return true;
		} else {
			return false;
		}
	}

	public boolean goForward() {
		if(curr < totBlock) {	
			return setCurr(++curr);
		} else {
			return false;
		}
	}
	
	public boolean backward() {
		if(curr > 1) {
			return true;
		} else {
			return false;
		}
	}
	public boolean goBack() {
		if(curr > 1) {
			setCurr(--curr);
			return true;
		} else {
			return false;
		}		
	}
	public int getCurr() {
		return curr;
	}


	public boolean setCurr(int curr) {
		if(curr > 0 && curr < totBlock + 1) {
			this.curr = curr;
			setPre();setNext();
			return true;
		}
		return false;
	}


	public int getPre() {
		return pre;
	}


	private void setPre() {
		pre = --curr;
	}


	public int getNext() {
		return next;
	}


	private void setNext() {
		next = ++curr;
	}


	public int getBlockSize() {
		return blockSize;
	}


	public void setBlockSize(int blockSize) {
		this.blockSize = blockSize;
	}


	public int getTotCnt() {
		return totCnt;
	}


	public void setTotCnt(int totCnt) {
		this.totCnt = totCnt;
	}


	public int getTotBlock() {
		return totBlock;
	}


	public void setTotBlock() {
		if(totCnt % blockSize > 0) {
			totBlock = totCnt / blockSize + 1;		
		} else {
			totBlock = totCnt / blockSize;	
		}
	}
	private void setRow() {
		if(getCurr() > 5) {
			rowStart = getCurr() - 5;
		} else {
			rowStart = 1;
		}
		if(getCurr() + 5 < totBlock) {
			rowEnd = getCurr() + 5;
		} else {
			rowEnd = totBlock;
		}
	}
	
	
	public int getRowStart() {
		return rowStart;
	}

	public int getRowEnd() {
		return rowEnd;
	}
	@Override
	public String toString() {
		return "Pager [curr=" + curr + ", pre=" + pre + ", next=" + next + ", blockSize=" + blockSize + ", totCnt="
				+ totCnt + ", totBlock=" + totBlock + ", rowStart=" + rowStart + ", rowEnd=" + rowEnd + "]";
	}
		
}
