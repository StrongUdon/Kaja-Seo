package board;

import java.util.List;

public interface BoardIDAO {

	public boolean addBoard(BoardVO bvo);
	
	public List<BoardVO> boardList();
	
	public boolean update(BoardVO bvo);
	
	public BoardVO findBoard(int b_no);
	
	public boolean deleteBoard(int b_no);
}
