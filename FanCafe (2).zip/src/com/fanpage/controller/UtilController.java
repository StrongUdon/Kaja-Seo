package com.fanpage.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.MemberDAO;
import member.MemberVO;
import message.MessageDAO;
import message.MessageVO;

public class UtilController extends Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		      response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		String this_page = request.getRequestURI().substring(request.getContextPath().length());
		String[] split = this_page.split("/");
		// System.out.println(request.getRequestURI());
		// 세션 객체 구하기
		HttpSession session = request.getSession();

		String str = null;
		MemberDAO dao = null;
		MessageDAO msgdao = null;
		try {
			dao = new MemberDAO();
			msgdao = new MessageDAO();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		switch (split[2]) {

		case "signuppage.seo":
			str = "signup.jsp";
			break;
		case "loginpage.seo":
			str = "login.jsp";
			break;
		case "adminpage.seo":
			str = "adminpage.jsp";
			break;
		case "dropOutPage.seo":
			str = "mypage_DropOut.jsp";
			break;
		case "about.seo":
			if (request.getParameter("where").equals("intro"))
				str = "aboutTeacher.jsp";
			else if (request.getParameter("where").equals("map"))
				str = "aboutMap.jsp";
			break;
		// 어바웃 페이지
		case "community.seo":
			if (request.getParameter("where").equals("check"))
				str = "communitycheck.jsp";
			else if (request.getParameter("where").equals("question"))
				str = "communityquestion.jsp";
			break;
		// 커뮤니티 페이지
		case "goods.seo":
			str = "goods.jsp";
			break;
		case "schedule.seo":
			str = "schedule.jsp";
			break;
		case "dropOut.seo":
			MemberVO deleteMV = (MemberVO) session.getAttribute("login_data");
			if (dao.delete(deleteMV.getM_no())) {
				System.out.println("삭제 완료");
				session.removeAttribute("login_data");
				session.invalidate();
			} else {
				System.out.println("삭제 실패");
			}
			str = "forward.jsp";
			break;
		case "findPwpage.seo":
			if (request.getParameter("email_for_find") != null) {
				String find_email = request.getParameter("email_for_find");
				try {
					if (!dao.IsOverRap("email", find_email)) { // 이메일 조차 없으면
						request.setAttribute("msg", "입력하신 이메일이 존재하지 않습니다.");
						request.setAttribute("email", find_email);
					} else { // 일단 이메일이 있으면
						if (!dao.getOneInfo(find_email).getPnum().equals(request.getParameter("pnum_for_find"))) {
							request.setAttribute("msg", "이메일과 전화번호 정보가 틀립니다.");
						} else { // 이메일도 있고 전화번호도 맞는 상황 ==>
							request.setAttribute("change_ok", "change_ok");
						}
					}

				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
			str = "findPwPage.jsp";
			break;
		case "findPw.seo":
			if (dao.change_pw(request.getParameter("pw_email"), request.getParameter("new_pw"))) {
				System.out.println("변경성공");
			} else {
				System.out.println("변경실패");
			}
			str = "forward.jsp";
			break;
		case "nick_change.seo":
			MemberVO lo_data_change = (MemberVO) session.getAttribute("login_data");
			if (dao.change_info(lo_data_change.getEmail(), request.getParameter("mypage_nick"),
					lo_data_change.getPnum())) {
				System.out.println("변경성공");
				try {
					session.setAttribute("login_data", dao.getOneInfo(lo_data_change.getEmail()));
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("변경실패");
			}
			str = "forward.jsp";
			break;
		case "pnum_change.seo":
			MemberVO lo_data_change2 = (MemberVO) session.getAttribute("login_data");
			if (dao.change_info(lo_data_change2.getEmail(), lo_data_change2.getM_name(),
					request.getParameter("mypage_pnum"))) {
				System.out.println("변경성공");
				try {
					session.setAttribute("login_data", dao.getOneInfo(lo_data_change2.getEmail()));
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("변경실패");
			}
			str = "forward.jsp";
			break;
		case "pw_change.seo":
			MemberVO lo_data_change3 = (MemberVO) session.getAttribute("login_data");
			if (dao.change_pw(lo_data_change3.getEmail(), request.getParameter("mypage_pw"))) {
				System.out.println("변경성공");
				try {
					session.setAttribute("login_data", dao.getOneInfo(lo_data_change3.getEmail()));
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("변경실패");
			}
			str = "forward.jsp";
			break;
		case "signup.seo":
			String email = request.getParameter("email");
			String pw = request.getParameter("pw");
			String pnum = request.getParameter("pnum");
			String nickname = request.getParameter("nickname");

			MemberVO mvo = new MemberVO(0, email, pw, "", pnum, nickname, false, false);
			System.out.println();
			if (dao.insert(mvo)) {
				str = "forward.jsp";
			} else {
				str = "signup.jsp";
			}
			break;
		case "login.seo":

			String lg_email = request.getParameter("email");
			String lg_pw = request.getParameter("pw");

			try {
				MemberVO mv = dao.getOneInfo(lg_email);
				if (dao.IsOverRap("email", lg_email)) {

					if (mv.getPw().equals(lg_pw)) {
						System.out.println(mv.getEmail());
						System.out.println(mv.getPw());
						session.setAttribute("login_data", mv);
						str = "forward.jsp";
					} else {
						str = login_fail(request);
					}
				} else {
					str = login_fail(request);
				}
			} catch (NumberFormatException | SQLException e) {
				str = login_fail(request);
			}
			break;
		case "logout.seo":
			MemberVO login_data = (MemberVO) session.getAttribute("login_data");
			if (login_data != null) {
				session.removeAttribute("login_data");
				session.invalidate(); // 세션 무효화
			} else {
				System.out.println("잘못된 접근이 시도되었습니다.");
			}
			str = "forward.jsp";
			break;
		case "dropout.seo":
			MemberVO delete_data = (MemberVO) session.getAttribute("login_data");
			if (dao.delete(delete_data.getM_no())) {
				session.removeAttribute("login_data");
				session.invalidate(); // 세션 무효화
				str = "forward.jsp";
				System.out.println("회원탈퇴 성공");
			} else {
				System.out.println("회원탈퇴 실패");
			}
			break; // 회원탈퇴 성공시 세션 날리고 회원 삭제.
		case "mypage.seo":

			MemberVO mypageData = (MemberVO) session.getAttribute("login_data");

			if (request.getParameter("mypage_pw") == null) {
				str = "mypage_Check.jsp";
				System.out.println("비밀번호 없이 마이페이지 접속!");
			} else if (request.getParameter("mypage_pw").equals(mypageData.getPw())) {
				str = "mypage.jsp";
				System.out.println("비밀번호 입력 수정페이지 접속!");
			} else {
				str = "forward.jsp";
				System.out.println("비밀번호 오류");
			}
			break;
		case "message.seo": /* 받은 메시지함 출력 */
			MemberVO msgData = (MemberVO) session.getAttribute("login_data");
			ArrayList<MessageVO> msg_list = new ArrayList<>();

			try {
				msgdao = new MessageDAO();
				msg_list = msgdao.getContentList(msgData.getM_name());
				System.out.println("컨트롤러/받은메시지함: " + msg_list);

				request.setAttribute("msg_list", msg_list);

				session.setAttribute("this_page", this_page);
				System.out.println(this_page);

			} catch (ClassNotFoundException e) {
				System.out.println("class not found error");
				e.printStackTrace();
			} catch (SQLException e) {
				System.out.println("sql error");
				e.printStackTrace();
			}

			str = "message.jsp";
			break;

		case "msgSendList.seo": /* 보낸 메시지함 출력 */
			MemberVO msgData2 = (MemberVO) session.getAttribute("login_data");
			ArrayList<MessageVO> msg_list1 = new ArrayList<>();
			try {
				msgdao = new MessageDAO();
				msg_list1 = msgdao.getSendContentList(msgData2.getM_name());
				System.out.println("컨트롤러/보낸메시지함: " + msg_list1);
				request.setAttribute("msg_list1", msg_list1);

				session.setAttribute("this_page", this_page);
				System.out.println(this_page);
			} catch (ClassNotFoundException e) {
				System.out.println("class not found error");
				e.printStackTrace();
			} catch (SQLException e) {
				System.out.println("sql error");
				e.printStackTrace();
			}
			str = "messageSendList.jsp";
			break;

		case "msgContent.seo": /* 메시지 한개 상세보기 */

			int messageNo = Integer.parseInt(request.getParameter("message_no"));
			System.out.println("컨트롤러에서 messageNO: " + messageNo);

			try {
				msgdao = new MessageDAO();
				MessageVO msgvo = msgdao.getContent(messageNo);
				session.setAttribute("msgvo", msgvo);
			} catch (ClassNotFoundException e) {
				System.out.println("class not found error");
				e.printStackTrace();
			} catch (SQLException e) {
				System.out.println("sql error");
				e.printStackTrace();
			}
			String z = (String) session.getAttribute("this_page");
			System.out.println("z: " + z);
			str = z.substring(1);
			break;

		case "msgDelete.seo": /* 메시지 삭제 */
			if(request.getParameter("delcheck")!=null) {
				String[] i_list = request.getParameterValues("delcheck");
			
				for (String string : i_list) {
					System.out.println(string);
				}

				int[] idf = new int[i_list.length];

				for (int i = 0; i < i_list.length; i++) {
					idf[i] = Integer.parseInt(i_list[i]);
				}
				for (int i = 0; i < idf.length; i++) {
					if (msgdao.del_message(idf[i]))
						System.out.println("del");
					else
						System.out.println("error");
				}

			// 메시지 삭제 후에 있던 페이지에 그대로 있게하기 위함
				String page2 = (String) session.getAttribute("this_page");
				str = page2.split("/")[2];
			}else {
				request.setAttribute("delete_alert", "fail");
				String page2 = (String) session.getAttribute("this_page");
				str = page2.split("/")[2];
			}
			break;
		case "msgSend.seo": /*메시지 개별 전송*/
			/* 메시지 전송 폼에 입력 후 전송 버튼 누르면 정보 db에 인서트 처리 작업 */
			/* 여러명 구분자: ,(쉼표) */
			MemberVO mvo1 = (MemberVO) session.getAttribute("login_data"); /* 보내는 사람 닉넴 가져오기 위해 현재 로긴 데이터 객체 생성 */
			String receiverS = request.getParameter("receiver");
			
			String[] receiverArray = receiverS.split(",");
			for (int i = 0; i < receiverArray.length; i++) {
				String receiver = receiverArray[i];
				System.out.println(receiver);
				Timestamp t = new Timestamp(System.currentTimeMillis());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
				String send_date = sdf.format(t);

				String title = request.getParameter("title");
					if (title == "" || title == null) {
						title = "제목없음";
					}

				String text = request.getParameter("text");
				
				//boolean noti = false; // 기본값은 false: 공지에 체크X , 개별 발송
				boolean noti = false;
				boolean read = false; // 기본값은 false: 읽지 않음 상태

				MessageVO msgvo = new MessageVO(0, mvo1.getM_name(), receiver, send_date, title, text, noti, read);

					if (msgdao.send(msgvo)) {
						System.out.println(msgvo.toString());
					} else {
						request.setAttribute("alert", "fail");
					}

				// 모달에서 메시지 전송 후에 있던 페이지에 그대로 있게하기 위함
				String page1 = (String) session.getAttribute("this_page");
				str = page1.split("/")[2];

			}
			break;
			
			
		case "msgAllSend.seo": //메시지 전체 전송(공지)
			ArrayList<MemberVO> all_list1 = new ArrayList<>();
			MemberVO mvoadmin = (MemberVO) session.getAttribute("login_data");
			try {
				dao=new MemberDAO();
				all_list1=dao.getAllInfo();
				System.out.println("컨트롤러에서 메시지 전체 전송위한 getAllinfo: "+all_list1);
				String receiverarray[] = new String[all_list1.size()];
				
				for (int i = 0; i < all_list1.size(); i++) {
					MemberVO member = all_list1.get(i);
					receiverarray[i] = member.getM_name();
				}
				System.out.println("컨트롤러에서 전체회원 닉네임 배열: "+receiverarray);
				
				
				for (int i = 0; i < receiverarray.length; i++) {
					String receiver = receiverarray[i];
					Timestamp t = new Timestamp(System.currentTimeMillis());
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
					String send_date = sdf.format(t);

					String title = request.getParameter("title");
						if (title == "" || title == null) {
							title = "제목없음";
						}

					String text = request.getParameter("text");
					
					//boolean noti = false; // 기본값은 false: 공지에 체크X , 개별 발송
					boolean noti = true;
					boolean read = false; // 기본값은 false: 읽지 않음 상태

					MessageVO msgvo = new MessageVO(0, mvoadmin.getM_name(), receiver, send_date, title, text, noti, read);

						if (msgdao.send(msgvo)) {
							System.out.println(msgvo.toString());
						} else {
							request.setAttribute("alert", "fail");
						}

					// 모달에서 메시지 전송 후에 있던 페이지에 그대로 있게하기 위함
					String page3 = (String) session.getAttribute("this_page");
					str = page3.split("/")[2];

				}
				
				
			} catch (ClassNotFoundException | SQLException e1) {
				e1.printStackTrace();
			}
			break;
			
			
		case "admin.seo": //관리자 페이지 : 전체 회원 목록  (여기에서 회원 대상 메시지(공지) 전송)
			ArrayList<MemberVO> all_list = new ArrayList<>();
			try {
				dao=new MemberDAO();
				all_list=dao.getAllInfo();
				System.out.println("컨트롤러 모든회원 정보: " + all_list);
				request.setAttribute("all_list", all_list);
				
				session.setAttribute("this_page", this_page);
				System.out.println(this_page);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			str = "adminpage.jsp";
			break;

		case "noticeSend.seo": // 보낸 공지함 
	         MemberVO msgData4 = (MemberVO) session.getAttribute("login_data");
	         // 운영자의 로그인 데이터를 가져와서 
	         ArrayList<MessageVO> msg_list2 = new ArrayList<>();
	         // 빈 배열을 만듭니다.
	         try {
	            msgdao = new MessageDAO();
	            // dao 객체 생성하고 
	            msg_list2 = msgdao.getSendContentList(msgData4.getM_name());
	            // 빈배열에 운영자가 sender인 모든 메세지를 가져옵니다.
	            ArrayList<MessageVO> noti_list_before = new ArrayList<>();
	            // 공지리스트와 
	            ArrayList<MessageVO> unnoti_list = new ArrayList<>();
	            // 비공지리스트로 나눠서 
	            for (int i = 0; i < msg_list2.size(); i++) {
	               if(msg_list2.get(i).isIs_notice()) {// 공지에 true 라면 
	                  noti_list_before.add(msg_list2.get(i)); //공지리스트에 
	               }else {   //아니라면                  
	                  unnoti_list.add(msg_list2.get(i)); //비공지리스트에 넣어줍니다. 
	               }
	            }
	            
	            ArrayList<MessageVO> noti_list = new ArrayList<>();
	            int num = 0;
	            noti_list.add(noti_list_before.get(0));
	            for (int i =0; i < noti_list_before.size(); i++) {
	                String a = noti_list_before.get(i).getSend_date();
	                for (int j = num; j < noti_list.size(); j++) {
	                  if(!noti_list.get(j).getSend_date().equals(a)) {
	                     noti_list.add(noti_list_before.get(i));
	                     num++;
	                  }
	               }   
	            }// 여기는 공지리스트에 들어있는 반복문중 "같은날짜"인것들을 제외하고 새로 만들어 주는 메서드
	            
	            System.out.println("컨트롤러/보낸공지함: " + noti_list);            
	            System.out.println("컨트롤러/보낸메시지함: " + unnoti_list);            
	            
	            request.setAttribute("noti_list", noti_list);
	            request.setAttribute("unnoti_list", unnoti_list);
	            //각각을 이런이름으로 보내줍니다.
	            
	            session.setAttribute("this_page", this_page);
	            System.out.println(this_page);
	         } catch (ClassNotFoundException e) {
	            System.out.println("class not found error");
	            e.printStackTrace();
	         } catch (SQLException e) {
	            System.out.println("sql error");
	            e.printStackTrace();
	         }
	         str="adminSendList.jsp";
	         break;

		}
		RequestDispatcher rd = request.getRequestDispatcher(str);
		rd.forward(request, response);
	}

	private String login_fail(HttpServletRequest request) {
		request.setAttribute("alert", "alert");
		System.out.println("login error!");
		return "login.jsp";
	}
}
