package com.fanpage.controller;



import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.seo")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      HashMap<String, Controller> urlMap = null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		urlMap = new HashMap<String, Controller>();
		urlMap.put("util", new UtilController());
		urlMap.put("boards", new BoardController());
		urlMap.put("goods", new GoodsController());
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getRequestURI();
		System.out.println("url: " + url);
		String contextPath = request.getContextPath();
		System.out.println("contextPath: " + contextPath);
		String path = url.substring(contextPath.length());
		System.out.println("path: " + path);
		String[] split = path.split("/");
		System.out.println("split: " + split[1]);
		Controller ic = (Controller) urlMap.get(split[1]);
		ic.execute(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		service(request, response);
	}

}
