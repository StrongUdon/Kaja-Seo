package com.fanpage.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import member.MemberDAO;
import member.MemberVO;
import article.ArticleDAO;
import article.ArticleVO;
import board.BoardDAO;
import board.BoardVO;
import board.Pager;
import reply.ReplyDAO;
import reply.ReplyVO;


public class BoardController extends Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getRequestURI();
		System.out.println("url: " + url);
		String contextPath = request.getContextPath();
		System.out.println("contextPath: " + contextPath);
		String path = url.substring(contextPath.length());
		System.out.println("path: " + path);
		String[] split = path.split("/");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			HttpSession session = request.getSession();
			MemberDAO mdao = null;
			ArticleDAO adao = null;
			ReplyDAO rdao = null;
			BoardDAO bdao = null;
			ArticleVO avo = null;
			ReplyVO rvo = null;
			BoardVO bvo = null;
			MemberVO mvo = null;
			List<ArticleVO> aList = null;
			List<ReplyVO> rList = null;
			List<BoardVO> bList = null;
			String str = null;
			System.out.println(request.getMethod() + "메서드" + split[2]);

				switch (split[2]) {
				
				case "login.seo":
					System.out.println("login.seo 선택");
					str = "/login.jsp";
					break;
					
				case "check.seo":
					String email = request.getParameter("email");
					String pw = request.getParameter("pw");
					System.out.println("check.seo: email = " + email + "; pw = " + pw + ";" );					
					try {
						mdao = new MemberDAO();
						mvo = mdao.getOneInfo(email, pw);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NullPointerException e1) {
						e1.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					if ( mvo != null) {
						session = request.getSession();
						session.setAttribute("login_data", mvo);
						str = "selectboard.seo";
					} else {
						str = "login.seo";
					}
					break;
				case "selectboard.seo":
					System.out.println("select.seo 선택");
					try {
						rdao = new ReplyDAO();
						bList = new ArrayList<BoardVO>();
						bdao = new BoardDAO();
						bList = bdao.boardList();
						request.setAttribute("boardList", bList);
					} catch (ClassNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					str = "boardselect.jsp";
					break;
					
				case "articleall.seo":
					System.out.println("articleall.seo 선택");
					String sort = "";
					int b_no = 1;
					int index = 1;
					Pager pg = null;
					String head_name = null;
					try {
						BoardDAO bd = new BoardDAO();
						adao = new ArticleDAO();
						sort = request.getParameter("sort") == "" ? "created_at": request.getParameter("sort");
						b_no = request.getParameter("b_no") == ""? 1: Integer.valueOf(request.getParameter("b_no"));
						head_name = bd.findBoard(Integer.parseInt(request.getParameter("b_no"))).getB_name();
						index = request.getParameter("index") == null ? 1 : Integer.valueOf(request.getParameter("index"));
						pg = request.getAttribute("pg")== null? new Pager(5,adao.count(b_no)): (Pager) request.getAttribute("pg");
						System.out.println(sort + ";;" + b_no + ";;" + index+ ";;" + pg);
					switch(sort) {
					case "modified_at":
							aList = adao.getAllInfo(b_no, ArticleDAO.MODIFIED_AT, index, pg);
						break;
					case "title":
						aList = adao.getAllInfo(b_no, ArticleDAO.TITLE, index, pg);
						break;
					default:
						aList = adao.getAllInfo(b_no, ArticleDAO.CREATED_AT, index, pg);
						break;
					}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch(NullPointerException e) {
						str = "boardselect.seo";
						break;
					}
					
					request.setAttribute("b_name", head_name);
					request.setAttribute("b_no", b_no);
					request.setAttribute("articleList", aList);
					request.setAttribute("pg", pg);
					str = "Board.jsp";
					break;
					
				case "articleform.seo":
					int b_no2= Integer.valueOf(request.getParameter("b_no"));
					if (session.getAttribute("login_data") != null) {
						request.setAttribute("b_no", b_no2);
						str= "articleform.jsp";
					} else {
						str="articleall.seo?b_no=" + b_no2 + "&sort=created_at&index=1";
					}
					break;
					
				case "addarticle.seo":
					System.out.println("addarticle.seo 선택");
					   // 웹서버 컨테이너 경로
				    String root = request.getSession().getServletContext().getRealPath("/");		 
				    // 파일 저장 경로(ex : /home/tour/web/ROOT/upload)
				    String savePath = root + "upload";
					File dir = new File(savePath);
					if (!dir.exists()) {
						dir.mkdirs();
					}

					MemberVO user = (MemberVO) session.getAttribute("login_data");
					MultipartRequest multi = new MultipartRequest(
							request,
							savePath,
							1024*1024*5,
							"utf-8",
							new DefaultFileRenamePolicy()
							);
					String title = multi.getParameter("title");
					String content = multi.getParameter("content");
					int b_no1 = Integer.valueOf(multi.getParameter("b_no"));
					String pic_uri = "";
					
					try {
							pic_uri = multi.getFilesystemName("thumb");
					} catch(NullPointerException e) {
						e.printStackTrace();
					}	
					ArticleVO article =  new ArticleVO(b_no1, pic_uri, user.getM_no(), title, content);
					try {
						adao = new ArticleDAO();
						if(adao.write(article)) {
							str = "articleall.seo?sort=created_at&index=1&b_no=" + b_no1;
						} else {
							str = "articleform.seo?b_no=" + b_no1;
						}
					} catch (ClassNotFoundException | SQLException e3) {
						// TODO Auto-generated catch block
						e3.printStackTrace();
					}

					break;
				case "article.seo":
					try {
						adao = new ArticleDAO();
						rdao = new ReplyDAO();
						avo = adao.getOneInfo(Integer.valueOf(request.getParameter("a_no")));
						request.setAttribute("article", avo);
						mdao = new MemberDAO();
						request.setAttribute("writer", mdao.findMemberByMno(avo.getM_no()));
						rList = rdao.findRepliesByArticle(avo);
						request.setAttribute("replyList", rList);
					} catch (ClassNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					str = "boarddetail.jsp";
					break;
					
				case "articleedit.seo":
					int a_no4 = Integer.valueOf(request.getParameter("a_no"));
					try {
						adao = new ArticleDAO();
						avo = adao.getOneInfo(a_no4);
						request.setAttribute("article", avo);
					} catch (ClassNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					str = "articleedit.jsp";
					break;
					
				case "updatearticle.seo":
					System.out.println("updatearticle.seo 선택");
				    String root1 = request.getSession().getServletContext().getRealPath("/");		 
				    String savePath1 = root1 + "upload";
					File dir1 = new File(savePath1);
					if (!dir1.exists()) {
						dir1.mkdirs();
					}
					MemberVO user1 = (MemberVO) session.getAttribute("login-data");
					MultipartRequest multi1 = new MultipartRequest(
							request,
							savePath1,
							1024*1024*5,
							"utf-8",
							new DefaultFileRenamePolicy()
							);
					int a_no3 = Integer.valueOf(multi1.getParameter("a_no"));
					String title1 = multi1.getParameter("title");
					String content1 = multi1.getParameter("content");
					int b_no5 = Integer.valueOf(multi1.getParameter("b_no"));
					String pic_uri1 = "";
					
					try {
							pic_uri = multi1.getFilesystemName("thumb");
					} catch(NullPointerException e) {
						e.printStackTrace();
					}		
					avo =  new ArticleVO(a_no3, b_no5, pic_uri1, user1.getM_no(), title1, content1);
					
					if(adao.update(avo)) {
						str = "articleall.seo?sort=created_at&index=1&b_no=" + b_no5;
					} else {
						str = "articleedit.seo?a_no=" + a_no3 + "&b_no=" + b_no5;
					}
					break;
					
				case "deletearticle.seo":
					System.out.println("deletearticle.seo 선택");
					int a_no = Integer.valueOf(request.getParameter("a_no"));
					System.out.println(a_no);
					int b_no3 = Integer.valueOf(request.getParameter("b_no"));
					try {
						adao = new ArticleDAO();
						if(adao.delete_art(a_no)) {
							System.out.println("article delete success");
						} else {
							System.out.println("article delete fail");							
						}
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					str = "articleall.seo?sort=created_at&index=1&b_no=" + b_no3;
					break;	
					
				case "addReply.seo":
					System.out.println("addreply.seo 선택");
					int article_no = Integer.valueOf(request.getParameter("a_no"));					
					try {
						mvo = (MemberVO) session.getAttribute("login_data");
						String name = mvo.getM_name();
						
					} catch (NullPointerException e) {
						str = "article.seo?a_no=" + article_no;
						break;
					}
					int depth = Integer.valueOf(request.getParameter("re_depth"));
					String rContent = request.getParameter("content");
					rvo = new ReplyVO(article_no, mvo.getM_no(), rContent );
					try {
						rdao = new ReplyDAO();
						rdao.postReply(rvo, depth);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

						str = "article.seo?a_no=" + article_no;
					break;
					
				case "boardform.seo":
					System.out.println("boardform.seo 선택");
					str = "boardform.jsp";
					break;

				case "deleteboard.seo":
					System.out.println("deleteboard.seo 선택");
					int b_no4 = Integer.valueOf(request.getParameter("b_no"));
					try {
						bdao = new BoardDAO();
						if(bdao.deleteBoard(b_no4)) {
							System.out.println("board delete success");

						} else {
							System.out.println("delete fail");							
						}

					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					str = "selectboard.seo";				
					break;
					
				case "addboard.seo":
					System.out.println("addboard.seo 선택");
					try {
						bdao = new BoardDAO();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(bdao.addBoard(new BoardVO(request.getParameter("b_name"), request.getParameter("detail")))) {

					str= "selectboard.seo";
					} else {
						str= "boardform.seo";
					}
					break;
					
				case "editboard.seo":
					int b_no7 = Integer.valueOf(request.getParameter("b_no"));
					try {
						bdao = new BoardDAO();
						bvo = bdao.findBoard(b_no7);
						request.setAttribute("board", bvo);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					str="boardedit.jsp";
					break;
					
				case "updateboard.seo":

					int b_no6 = Integer.valueOf(request.getParameter("b_no"));
					String b_name = request.getParameter("b_name");
					String detail = request.getParameter("detail");
					System.out.println("updateboard.seo 선택" + b_no6 +";;" + b_name + ";;" + detail);
					try {
						bdao = new BoardDAO();

					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(bdao.update(new BoardVO(b_no6, b_name, detail))) {
						str = "selectboard.seo";
					} else {
						str = "boardform.seo";
					}
					break;
				}
					
				System.out.println( str + "디스패쳐");
				RequestDispatcher rd1 = request.getRequestDispatcher( str);
				rd1.forward(request, response);	
			}
		
	}


