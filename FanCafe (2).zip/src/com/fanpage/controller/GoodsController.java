package com.fanpage.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import Goods.GoodsDAO;
import Goods.GoodsVO;
import Goods_P.Goods_P_DAO;
import Goods_P.Goods_P_VO;
import member.MemberDAO;
import member.MemberVO;
import review.ReviewDAO;
import review.ReviewVO;

public class GoodsController extends Controller {
	
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession();

		String shippingFee = null;
		int min_val = 0;

		/* ArrayList<Integer> wList = null; */
		ArrayList<GoodsVO> goodsList = null;
		ArrayList<GoodsVO> goodsOrder = null;
		ArrayList<Integer> wishList = null;
		List<ReviewVO> reviewList = null;

		GoodsDAO gdao = null;
		MemberDAO mdao = null;
		ReviewDAO rdao = null;
		try {
			gdao = new GoodsDAO();
			mdao = new MemberDAO();
			rdao = new ReviewDAO();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String c = request.getRequestURI().substring(request.getContextPath().length());
		String[] split = c.split("/");
		
		String str = null;
		String fee = null;

		System.out.println(c);
		switch (split[2]) {

		case "login.seo":
			str = "login.jsp";
			break;

		case "check.seo":
			String email = request.getParameter("email");
			System.out.println(email);
			String pw = request.getParameter("pw");
			System.out.println(pw);
			MemberVO mvo = null;
			try {
				mvo = mdao.getOneInfo(email, pw);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("에러1");
			} catch (NullPointerException e1) {
				e1.printStackTrace();
				System.out.println("에러2");
			}

			if (mvo != null) {
				session = request.getSession();
				session.setAttribute("user", mvo);
				str = "getAllGoods.seo";// 수정
			} else {
				mvo = (MemberVO) session.getAttribute("user");
				if (mvo != null) {
					session = request.getSession();
				} else {
					str = "login.seo";
					System.out.println("mvo가 null입니다.");
				}
			}
			break;

		case "wishList.seo":
			int g_no4 = Integer.parseInt(request.getParameter("g_no"));
			
			if(session.getAttribute("login_data")==null) {
				int guest=0;
				request.setAttribute("guest", guest);
				str = "getAllGoods.seo";
			}else {
			MemberVO mvo1 = (MemberVO) session.getAttribute("login_data");
			boolean b1 = gdao.insert_wish(g_no4, mvo1.getM_no());
			if (b1) {
				System.out.println(g_no4 + "를 찜했습니다."); // test
			} else {
				System.out.println(g_no4 + "는 이미 찜한 상품입니다.");
				boolean b2 = gdao.delete_wish(g_no4, mvo1.getM_no());
				if (b2) {
					System.out.println(g_no4 + "를 찜 취소했습니다.");
				} else {
					System.out.println(g_no4 + "를 찜 취소 실패..");
				}
			}

			str = "getAllGoods.seo";
			}
			break;
		
		case "getAllGoods.seo": // 상품 전체보기, 등록순 정렬 비회원 접근 가능
			
			if(null!=request.getAttribute("guest")) {
				System.out.println("getAllGoods.seo에 넘어온 값 " + request.getAttribute("guest"));
				int guest = (int) request.getAttribute("guest");
				request.setAttribute("guest", guest);
			}
			try {
				goodsList = gdao.getAllGoods();
				goodsOrder = gdao.orderBySold();
				wishList = gdao.count_wish();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("getAllGoods.seo error");
			}

			if(goodsList.isEmpty()) {
				request.setAttribute("goodsList", null);
			
			}else if(goodsList.size()==1){
				request.setAttribute("gv1", goodsOrder.get(0));
				
				request.setAttribute("goodsList", goodsList);
				request.setAttribute("wishList", wishList);
			}else if(goodsList.size()==2) {
				request.setAttribute("gv1", goodsOrder.get(0));
				request.setAttribute("gv2", goodsOrder.get(1));
				
				request.setAttribute("goodsList", goodsList);
				request.setAttribute("wishList", wishList);
				
			}else {	
				request.setAttribute("gv1", goodsOrder.get(0));
				request.setAttribute("gv2", goodsOrder.get(1));
				request.setAttribute("gv3", goodsOrder.get(2));
				
				request.setAttribute("goodsList", goodsList);
				request.setAttribute("wishList", wishList);
			}
			str = "GoodsView.jsp";
			break;

		case "find_wishList.seo": //비회원 접근 불가 
			MemberVO mvo2 = (MemberVO) session.getAttribute("login_data");
			
			if(mvo2==null) { //비회원이라면 
				System.out.println("find_wishList.seo error 비회원");
				str = "getAllGoods.seo";
			}else {
			String m_name = mvo2.getM_name();
			int m_no = mvo2.getM_no();
			int cntGoods = 0;
			try {
				cntGoods = gdao.count_goods(m_no);
				wishList = gdao.find_wishList(mvo2.getM_no());
				System.out.println(cntGoods + "개 찜하셨습니다.");
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			goodsList = new ArrayList<GoodsVO>();
			for (Integer g_no : wishList) {
				GoodsVO gv = null;
				try {
					gv = gdao.searchDetail(g_no);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				goodsList.add(gv);
			}
			request.setAttribute("cntGoods", cntGoods);
			request.setAttribute("m_name", m_name); 
			request.setAttribute("goodsList", goodsList);
			str = "User_WishList.jsp";
			}
			
			break;

		case "GoodsDetail.seo": // 상품 1개 상세보기
			int g_no = Integer.parseInt(request.getParameter("g_no"));
			MemberVO mvo6 = (MemberVO) session.getAttribute("login_data");
			
			if(mvo6!=null) {//비회원인 경우
				String m_name3 = mvo6.getM_name();
				request.setAttribute("m_name", m_name3);
			}

			GoodsVO gv1 = null;
			ArrayList<Integer> user_wish = null;
			int avg_rate = 0;
			try {
				gv1 = gdao.searchDetail(g_no);
				goodsList = new ArrayList<GoodsVO>();
				goodsList.add(gv1);
				user_wish = gdao.find_wishList(g_no);
				reviewList = rdao.findReviewsByGoods(g_no);
				avg_rate = gdao.avg_rate(g_no);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("GoodsDetail.seo" + "에러");
			}
			
			request.setAttribute("avg_rate", avg_rate);
			request.setAttribute("reviewList", reviewList);
			request.setAttribute("user_wish", user_wish);
			request.setAttribute("goodsList", goodsList);
			str = "GoodsDetail.jsp";
			break;

		case "Add_Cart.seo": // 장바구니에 상품 추가

			int g_no1 = Integer.parseInt(request.getParameter("g_no"));
			int cnt = Integer.parseInt(request.getParameter("cnt"));
			GoodsVO gv2 = null;
			try {
				gv2 = gdao.searchDetail(g_no1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("p = gdao.searchDetail(g_no1); 에러");
			}

			ArrayList<GoodsVO> gList = null;
			ArrayList<Integer> cntList = null;
			int totPrice = 0;

			Boolean flag = true;

			if (null == session.getAttribute("gList")) {
				gList = new ArrayList<>();
				cntList = new ArrayList<>();
				gList.add(gv2);
				cntList.add(cnt);
				totPrice = gv2.getPrice() * cnt;
				flag = false;

			} else {
				gList = (ArrayList<GoodsVO>) session.getAttribute("gList");
				cntList = (ArrayList<Integer>) session.getAttribute("cntList");
				totPrice = (Integer) session.getAttribute("totPrice");
				for (int i = 0; i < gList.size(); i++) {
					if (gList.get(i).getG_no() == g_no1) { // g_no1번 상품이 gList에 있다면
						System.out.println("장바구니 속 상품: " + gList.get(i).getG_no() + "가 넘어온 상품:" + g_no1 + "이라면");
						totPrice -= gList.get(i).getPrice() * cntList.get(i); // 원래 금액 빼기
						int updateCnt = cntList.get(i) + cnt;
						cntList.set(i, updateCnt);
						totPrice += gList.get(i).getPrice() * cntList.get(i); // 수정된 금액 더하기
						flag = false;
						break;
					}
				}
				if (flag) {
					gList.add(gv2);
					cntList.add(cnt);

					totPrice += gv2.getPrice() * cnt;
				}
			}

			try {
				fee = gdao.checkFee(totPrice);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("배송비 체크 에러");
			}

			if (fee.equals("무료배송")) {
				shippingFee = "0";
			} else {
				shippingFee = "2500";
				try {
					min_val = gdao.min_val();
					System.out.println(min_val);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("배송 최소값 에러");
				}
			}

			session.setAttribute("gList", gList);
			session.setAttribute("cntList", cntList);
			session.setAttribute("totPrice", totPrice);

			gList = (ArrayList<GoodsVO>) session.getAttribute("gList");
			cntList = (ArrayList<Integer>) session.getAttribute("cntList");
			totPrice = (Integer) session.getAttribute("totPrice");

			
			int total = totPrice + Integer.parseInt(shippingFee);
			session.setAttribute("total", total);
			
			request.setAttribute("min_val", min_val);
			request.setAttribute("fee", fee);
			request.setAttribute("shippingFee", shippingFee);
			request.setAttribute("totPrice", totPrice);

			str = "User_Cart.jsp";
			// str = "showCart.seo"; // 추후에 모달 사용-> 장바구니 확인하기showCart.seo or 계속 쇼핑하기
			// 선택goodsListView.jsp
			break;

		case "showCart.seo":

			gList = (ArrayList<GoodsVO>) session.getAttribute("gList");
			if (null == session.getAttribute("gList") || 0 == gList.size()) {
				str = "User_Cart.jsp";
			} else {
				cntList = (ArrayList<Integer>) session.getAttribute("cntList");
				totPrice = (Integer) session.getAttribute("totPrice");

				try {
					fee = gdao.checkFee(totPrice);
				} catch (SQLException e) { // TODO Auto-generated catch block e.printStackTrace();
					System.out.println("배송비 체크 에러");
				}
				if (fee.equals("무료배송")) {
					shippingFee = "0";
				} else {
					shippingFee = "2500";
					try {
						min_val = gdao.min_val();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				int total1 = totPrice + Integer.parseInt(shippingFee);
				session.setAttribute("total", total1);
				
				request.setAttribute("min_val", min_val);
				request.setAttribute("fee", fee);
				request.setAttribute("shippingFee", shippingFee);
				request.setAttribute("totPrice", totPrice);
				str = "User_Cart.jsp";
			}
			break;

		case "delete.seo": // 선택한 상품 장바구니에서 빼기
			
			String[] sg_no = request.getParameterValues("g_no");
			
			int[] g_noArr = new int[sg_no.length-1];
			for (int i = 0; i < g_noArr.length; i++) {
				g_noArr[i] = Integer.parseInt(sg_no[i]);
			}
			
			if(null == session.getAttribute("gList")) {
				str = "User_Cart.jsp";
			}else {
			ArrayList<GoodsVO> gList2 = (ArrayList<GoodsVO>) session.getAttribute("gList"); 
			ArrayList<Integer> cntList2 = (ArrayList<Integer>) session.getAttribute("cntList"); 
			int totPrice2 = (Integer) session.getAttribute("totPrice");
			
			for (int i = 0; i < g_noArr.length; i++) {
				for (int j = 0; j < gList2.size(); j++) {
					if (g_noArr[i] == gList2.get(j).getG_no()) { // 뺄 상품번호가 카트 속 상품번호와 같다면
						totPrice2 -= gList2.get(j).getPrice() * cntList2.get(j);
						System.out.println("장바구니에서 " + gList2.get(j).getG_name() + "을 삭제합니다.");
						gList2.remove(j);
						cntList2.remove(j);
					}
				}
			}

			try {
				fee = gdao.checkFee(totPrice2);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("배송비 체크 에러");
			}

			if (fee.equals("무료배송")) {
				shippingFee = "0";
			} else {
				shippingFee = "2500";
				try {
					min_val = gdao.min_val();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			int total1 = totPrice2 + Integer.parseInt(shippingFee);
			session.setAttribute("total", total1);
			
			session.setAttribute("gList", gList2);
			session.setAttribute("cntList", cntList2);
			session.setAttribute("totPrice", totPrice2);

			request.setAttribute("min_val", min_val);
			request.setAttribute("fee", fee);
			request.setAttribute("shippingFee", shippingFee);
			str = "User_Cart.jsp";
			}
			break;

		case "update.seo": // 상품 개수 변경
			int g_no3 = Integer.parseInt(request.getParameter("g_no"));
			System.out.println("넘어온 " + g_no3);

			ArrayList<GoodsVO> gList3 = (ArrayList<GoodsVO>) session.getAttribute("gList");
			ArrayList<Integer> cntList3 = (ArrayList<Integer>) session.getAttribute("cntList");
			int totPrice3 = (Integer) session.getAttribute("totPrice");

			for (int i = 0; i < gList3.size(); i++) {
				if (gList3.get(i).getG_no() == g_no3) {
					totPrice3 -= gList3.get(i).getPrice() * cntList3.get(i); // 원래 금액 빼기

					int updateCnt = 0;
					if (request.getParameter("btnUp") != null) {
						updateCnt = cntList3.get(i) + 1;
						cntList3.set(i, updateCnt);
						totPrice3 += gList3.get(i).getPrice() * cntList3.get(i);
					} else if (request.getParameter("btnDown") != null) {
						updateCnt = cntList3.get(i) - 1;
						if (updateCnt <= 0) {
							gList3.remove(i);
							cntList3.remove(i);
						} else {
							cntList3.set(i, updateCnt);
							totPrice3 += gList3.get(i).getPrice() * cntList3.get(i);
						}
					}
					System.out.println("상품 개수 변경으로 금액이 수정되었습니다.");
				}
			}
			try {
				fee = gdao.checkFee(totPrice3);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("배송비 체크 에러");
			}

			if (fee.equals("무료배송")) {
				shippingFee = "0";
			} else {
				shippingFee = "2500";
				try {
					min_val = gdao.min_val();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			int total11 = totPrice3 + Integer.parseInt(shippingFee);
			session.setAttribute("total", total11);
			
			session.setAttribute("gList", gList3);
			session.setAttribute("cntList", cntList3);
			session.setAttribute("totPrice", totPrice3);

			request.setAttribute("min_val", min_val);
			request.setAttribute("fee", fee);
			request.setAttribute("shippingFee", shippingFee);
			
			
			str = "User_Cart.jsp";
			break;

		case "insert_reply.seo": // 상품평의 댓글 입력
			MemberVO mvo4 = (MemberVO) session.getAttribute("login_data");
			int r_depth = Integer.valueOf(request.getParameter("r_depth"));
			int goods_no = Integer.valueOf(request.getParameter("g_no"));
			String content = request.getParameter("content");
			ReviewVO rvo = null;
			int guest = 999; //비회원 멤버번호 부여  
			if(mvo4!=null) { //회원이라면
				rvo = new ReviewVO(goods_no, mvo4.getM_no(), content);
			}
			else { //비회원이라면
				rvo = new ReviewVO(goods_no, guest , content);
			}
			
			rdao.postReview(rvo, r_depth); // 상품평 입력 메서드
			str = "show_review.seo?g_no=" + goods_no;
			break;

		case "insert_review.seo": // 상품평 입력
			MemberVO mvo5 = (MemberVO) session.getAttribute("login_data");

			String root = request.getSession().getServletContext().getRealPath("/");
			String uploadPath = root + "upload";

			File file = new File(uploadPath);
			if (!file.exists()) {
				file.mkdir();
			}
			MultipartRequest multi = new MultipartRequest(request, uploadPath, 1024 * 1024 * 10, "utf-8",
					new DefaultFileRenamePolicy());
			int r_depth2 = Integer.valueOf(multi.getParameter("r_depth"));
			int goods_no2 = Integer.valueOf(multi.getParameter("g_no"));
			String content2 = multi.getParameter("content");
			int s_rate2 = Integer.valueOf(multi.getParameter("s_rate"));
			int g_rate2 = Integer.valueOf(multi.getParameter("g_rate"));

			String img_uri2 = null;
			try {
				img_uri2 = multi.getFilesystemName("img_uri");
				System.out.println(uploadPath + " <--업로드 경로");
				System.out.println(img_uri2 + " 업로드된 파일이름");
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("업로드 실패");
			}
			System.out.println(
					"r_depth" + r_depth2 + "goods_no" + goods_no2 + "content" + content2 + "img_uri" + img_uri2);

			ReviewVO rvo2 = new ReviewVO(goods_no2, mvo5.getM_no(), content2, img_uri2, s_rate2, g_rate2);

			rdao.postReview(rvo2, r_depth2); // 상품평 입력 메서드
			str = "GoodsDetail.seo?g_no=" + goods_no2;
			// reviewList = rdao.findReviewsByGoods(goods_no);
			break;

		case "show_review.seo": // 상품평 보기
			int goods_no1 = Integer.valueOf(request.getParameter("g_no"));
			MemberVO mvo7 = (MemberVO) session.getAttribute("user");
			
			if(mvo7!=null) {
				String m_name4 = mvo7.getM_name();
				request.setAttribute("m_name", m_name4);
			}
			
			reviewList = rdao.findReviewsByGoods(goods_no1);
			
			request.setAttribute("reviewList", reviewList); // 리뷰리스트 보내기
			str = "GoodsDetail.seo?g_no=" + goods_no1;
			break;

		case "Goods_Review_check.seo": // 상품평 작성 권한 확인
			int goods_no3 = Integer.valueOf(request.getParameter("g_no"));
			MemberVO mvo8 = (MemberVO) session.getAttribute("login_data");
			int m_no2 = mvo8.getM_no();

			// if() 구매 테이블 - goods_no3, m_no2로 구매 여부 확인 - 상품평 등록 폼 이동

			request.setAttribute("g_no", goods_no3);
			str = "Goods_Review_Form.jsp";

			// else
			String check = null;
			check = "상품평 작성 권한이 없습니다.";
			request.setAttribute("check", check);
			request.setAttribute("g_no", goods_no3);
			str = "Goods_Review.jsp";
			break;

			
		case "pay.seo":
			MemberVO mvo9 = (MemberVO) session.getAttribute("login_data");

			int g_no11 = Integer.parseInt(request.getParameter("g_no"));
			
			/*int total = Integer.parseInt(request.getParameter("total"));*/
			request.setAttribute("g_no", g_no11);
			/*request.setAttribute("total", total);*/
			
			try {
				request.setAttribute("gname",gdao.searchname(g_no11));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			str = "pay.jsp";
			
			break;
		
		case "paycomplete.seo" : 
			
			MemberVO mvo10 = (MemberVO) session.getAttribute("login_data");

			
			Goods_P_DAO gpdao = null;
			
			
			try {
				gpdao = new Goods_P_DAO();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int g_no55 = Integer.parseInt(request.getParameter("g_no"));
			int m_no55= mvo10.getM_no();
			
			String imp_uid = request.getParameter("imp_uid");
			String gname = request.getParameter("gname");
			int amount = (int)session.getAttribute("totPrice");
			
			System.out.println(
					"여기 paycomplete.seo : " + imp_uid + " " + g_no55 + " " + gname + " " + amount + " " + m_no55);
			boolean insertis;
			boolean updatestock;
			try {
				insertis = gpdao.insert(imp_uid, g_no55, m_no55, amount);
				updatestock = gdao.updatestock(g_no55);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("gname", gname);
			str = "payend.seo";
			break;

		case "payend.seo" :
		    MemberVO mvo11 = (MemberVO)session.getAttribute("login_data");

		    
			
			try {
				Goods_P_DAO gpdao2 = new Goods_P_DAO();
				Goods_P_VO gpvo = gpdao2.getLatest();
				
				
				String p_no1 = gpvo.getP_no();
				String gname1 = gdao.searchname(gpvo.getG_no());
				request.setAttribute("gname", gname1);
				request.setAttribute("payed", gpvo);

				
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("응 에러야~");
				e.printStackTrace();
			}
			
			//카트 세션 비우기
			session.removeAttribute("gList");
			session.removeAttribute("cntList");
			session.removeAttribute("totPrice");
			System.out.println("카트 세션 비우기 성공");
		    
			str = "paycomplete.jsp";
			break;
			
		case "purchase_details.seo" :
			
		    MemberVO mvo12 = (MemberVO)session.getAttribute("login_data");
			int thism = mvo12.getM_no();
			ArrayList <Goods_P_VO> purlist = new ArrayList<Goods_P_VO>();

		    try {
				Goods_P_DAO gpdao1 = new Goods_P_DAO();
				purlist = gpdao1.getAllPurchased(thism);
				request.setAttribute("purlist", purlist);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
			str = "purchase_details.jsp";
			break;
			
		case "add_goods.seo":
			System.out.println("add_goods.seo로 넘어옴");
			
			String root1 = request.getSession().getServletContext().getRealPath("/");
			String uploadPath1 = root1 + "upload";

			File file1 = new File(uploadPath1);
			if (!file1.exists()) {
				file1.mkdir();
			}
			MultipartRequest multi1 = new MultipartRequest(request, uploadPath1, 1024 * 1024 * 10, "utf-8",
					new DefaultFileRenamePolicy());
			String g_name = multi1.getParameter("g_name");
			String detail = multi1.getParameter("detail");
			int g_left = Integer.parseInt(multi1.getParameter("g_left"));
			int g_sold = Integer.parseInt(multi1.getParameter("g_sold"));
			int price = Integer.parseInt(multi1.getParameter("price"));
			
			String img_uri = null; 
			
			try {
				img_uri = multi1.getFilesystemName("img_uri");
				System.out.println(uploadPath1 + " <--업로드 경로");
				System.out.println(img_uri + " 업로드된 파일이름");
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("업로드 실패");
			}
			
			gdao.add_goods(g_name, detail, img_uri, price, g_left, g_sold);
			
			str = "getAllGoods.seo";
			break;

		case "gdelete.seo":

			int g_nos = Integer.parseInt(request.getParameter("gno"));
			System.out.println(g_nos);
			try {
				gdao.delete(g_nos);
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			str = "getAllGoods.seo";

			
		}
		System.out.println("디스패치 최종경로:" + str);
		RequestDispatcher rd1 = request.getRequestDispatcher(str);
		rd1.forward(request, response);

	}
}
