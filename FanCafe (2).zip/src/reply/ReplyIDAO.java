package reply;

import java.util.ArrayList;
import java.util.List;

import article.ArticleVO;

public interface ReplyIDAO {
	boolean postReply(ReplyVO vo, int re_depth);
	boolean editReply(ReplyVO vo);
	boolean deleteReply(ReplyVO vo);
	List<ReplyVO> findRepliesByArticle(ArticleVO avo);
	List<ReplyVO> findRepliesByMember(int member_no);
	
}
