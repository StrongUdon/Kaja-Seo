package reply;

import java.util.Date;

public class ReplyVO {
	private int re_no;
	private int a_no;
	private int m_no;
	private String content;
	private Date created_at;
	private Date modified_at;
	private int parent;
	private int depth;
	private int re_order;
	private String m_name;

	public ReplyVO() {}
	public ReplyVO(int re_no, int a_no, int m_no, String content, Date created_at, Date modified_at, int parent,
			int depth, int re_order) {
		super();
		this.re_no = re_no;
		this.a_no = a_no;
		this.m_no = m_no;
		this.content = content;
		this.created_at = created_at;
		this.modified_at = modified_at;
		this.parent = parent;
		this.depth = depth;
		this.re_order = re_order;
	}
	
	public ReplyVO(int a_no, int m_no, String content) {
		super();
		this.a_no = a_no;
		this.m_no = m_no;
		this.content = content;
	}
	public int getRe_no() {
		return re_no;
	}
	public void setRe_no(int re_no) {
		this.re_no = re_no;
	}
	public int getA_no() {
		return a_no;
	}
	public void setA_no(int a_no) {
		this.a_no = a_no;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getCreated_at() {
		return created_at;
	}
	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}
	public Date getModified_at() {
		return modified_at;
	}
	public void setModified_at(Date modified_at) {
		this.modified_at = modified_at;
	}
	public int getParent() {
		return parent;
	}
	public void setParent(int parent) {
		this.parent = parent;
	}
	public int getRedepth() {
		return depth;
	}
	public void setRedepth(int depth) {
		this.depth = depth;
	}
	public int getRe_order() {
		return re_order;
	}
	public void setRe_order(int re_order) {
		this.re_order = re_order;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	@Override
	public String toString() {
		return "ReplyVO [re_no=" + re_no + ", a_no=" + a_no + ", m_no=" + m_no + ", content=" + content
				+ ", created_at=" + created_at + ", modified_at=" + modified_at + ", parent=" + parent + ", depth="
				+ depth + ", re_order=" + re_order + "]";
	}	
	
}
