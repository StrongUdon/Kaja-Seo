package reply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import article.ArticleVO;

import java.sql.Date;

import util.DBConn;

public class ReplyDAO implements ReplyIDAO {
	private Connection con; // MemberConn
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public ReplyDAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection();
				
	}

	@Override
	public boolean postReply(ReplyVO vo, int re_depth) {
		
		if(re_depth < 0) {
			int depth = findMaxDepth(vo.getA_no());
			String sql = "INSERT INTO REPLIES( re_no, "
			+ " a_no, m_no, "
			+ "content, re_parent, re_depth, re_order) "
			+ " VALUES( reply_increment.nextval, ?, ?, ?, 0, ?, 1 )";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, vo.getA_no());
				pstmt.setInt(2, vo.getM_no());
				pstmt.setString(3, vo.getContent());
				pstmt.setInt(4,  depth);
				if(pstmt.executeUpdate() == 1) {
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		} else {

			int order = findMaxOrder(vo.getA_no(), re_depth);
			int parent = findParent(vo.getA_no(), re_depth);
			vo.setRedepth(re_depth);
			vo.setRe_order(order);
			System.out.println("답글의 부모 아이디: " + findParent(vo.getA_no(), vo.getRedepth()) +
					" depth: " + re_depth + " order: " + order); 
			String sql1 = "INSERT INTO REPLIES( re_no, a_no, m_no, content, re_parent, re_depth, re_order) "
			+ " VALUES (reply_increment.nextval, ?, ?, ?, ?, ?, ?) ";
			try {
				pstmt = con.prepareStatement(sql1);
				pstmt.setInt(1, vo.getA_no());
				pstmt.setInt(2, vo.getM_no());
				pstmt.setString(3, vo.getContent());
				pstmt.setInt(4, parent);
				pstmt.setInt(5, re_depth);
				pstmt.setInt(6, vo.getRe_order());
				if(pstmt.executeUpdate() == 1) {
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
		
	}
	
	private int findReplyDepth(int article_no) {
		String sql = "SELECT MAX(RE_DEPTH)+1 " + 
				" FROM REPLIES " + 
				" WHERE A_NO = ? "; 
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, article_no);
			rs = pstmt.executeQuery();
			if(rs.next()){
				int depth = rs.getInt("max(re_depth)+1");
				return depth;			
		} else {
			System.out.println("Error in findReplyDepth");
			return -1;
		}
		
	} catch (SQLException e) {
		e.printStackTrace();

	}
		return -1;
	}
	
	private int findMaxDepth(int a_no) {
		
		String sql = " SELECT MAX(re_depth)+1 "
				+ " FROM REPLIES "
				+ "	WHERE A_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, a_no);
			rs = pstmt.executeQuery();
			if(rs.next()){
				int depth = rs.getInt("MAX(re_depth)+1");
				System.out.println(depth + " findmax_depth" );
				return depth;			
		} else {
			
			System.out.println("Error in findReplyByDepth");
			return -1;
		}
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
				
		return -1;
	}

	private int findMaxOrder(int a_no, int depth) {
		
		String sql = " SELECT MAX(RE_ORDER)+1 "
				+ " FROM REPLIES "
				+ "	WHERE A_NO = ? "
				+ " AND RE_DEPTH = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, a_no);
			pstmt.setInt(2, depth);
			System.out.println(a_no + " " + depth);
			rs = pstmt.executeQuery();
			if(rs.next()){
				int order = rs.getInt("MAX(RE_ORDER)+1");
				System.out.println(order);
				return order;			
		} else {
			System.out.println("Error in findReplyByORDER");
			return -1;
		}
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
				
		return -1;
	}
	private int findParent(int a_no, int depth) {
		String sql = "SELECT RE_NO FROM REPLIES "
				+ " WHERE A_NO = ? "
				+ " AND RE_DEPTH = ? "
				+ " AND RE_ORDER = 1 ";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, a_no);
			pstmt.setInt(2, depth);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				
				return rs.getInt("re_no");
			}
		} catch (SQLException e) {
			System.out.println("Error in findParent");
			e.printStackTrace();
		}

		
		return -1;
	}
	@Override
	public boolean editReply(ReplyVO vo) {
		String sql = "UPDDATE REPLIES"
				+ "	SET CONTENT = ? "
				+ " WHERE RE_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vo.getContent());
			pstmt.setInt(2, vo.getRe_no());
			if(pstmt.executeUpdate() == 1) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean deleteReply(ReplyVO vo) {
		String sql = "DELETE FROM REPLIES "
				+ "	WHERE RE_NO = ? ";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, vo.getRe_no());
			if(pstmt.executeUpdate() == 1) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public List<ReplyVO> findRepliesByArticle(ArticleVO avo) {
		String sql = "select ROWNUM, x.*, members.m_name " + 
				" from (select a.* from replies a order by re_depth, re_order)x, members " + 
				"where x.m_no = members.m_no and a_no= ? ";
		List<ReplyVO> rList = new ArrayList<ReplyVO>();
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, avo.getA_no());
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ReplyVO rvo = new ReplyVO(
						rs.getInt("ROWNUM"),
						rs.getInt("a_no"),
						rs.getInt("m_no"),
						rs.getString("content"),
						rs.getDate("created_at"),
						rs.getDate("modified_at"),
						rs.getInt("re_parent"),
						rs.getInt("re_depth"),
						rs.getInt("re_order")
						);
				rvo.setM_name(rs.getString("m_name"));
				rList.add(rvo);
				
			}
			return rList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<ReplyVO> findRepliesByMember(int member_no) {
		String sql = "SELECT REPLIES.*, M_NAME FROM REPLIES, MEMBERS"
				+ "	WHERE REPLIES.M_NO = MEMBERS.M_NO "
				+ "AND M_NO = ? ORDER BY CREATED_AT DESC";
		List<ReplyVO> rList = new ArrayList<ReplyVO>();
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, member_no);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ReplyVO rvo =new ReplyVO(
						rs.getInt("re_no"),
						rs.getInt("a_no"),
						rs.getInt("m_no"),
						rs.getString("content"),
						rs.getDate("created_at"),
						rs.getDate("modified_at"),
						rs.getInt("re_parent"),
						rs.getInt("re_depth"),
						rs.getInt("re_order")
						);
				rvo.setM_name(rs.getString("m_name"));
				rList.add(rvo);
			}
			return rList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	public int count(int a_no) {
		String sql = "SELECT count(*) "
				+ " FROM replies "
				+ " WHERE a_no = ? ";
		int cnt =-1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, a_no);
			rs = pstmt.executeQuery();
			rs.next();
			cnt = rs.getInt("count(*)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return cnt;
	}
	
	public void getAllInfoClose() throws SQLException {
		if(rs != null){ rs.close(); }
		if(pstmt != null){ pstmt.close(); }
		if(con != null){ con.close(); }
	}
}
