package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConn {

	private Connection con;	//접속객체 con 선언
	
	//getConnection() 메소드	: 반환타입은 Connection
	public Connection getConnection() {
		return con;	//접속객체 return
	}
	
	//생성자
	public DBConn() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.46:1521:xe", "hr", "hr");
	}
}
