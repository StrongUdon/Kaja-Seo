package article;

import java.util.Date;

public class ArticleVO {

	
	private Integer a_no;
	private Integer b_no;
	private String thumb_uri;
	private int m_no;
	private String title;
	private String content;
	private Date created_at;
	private Date modified_at;
	private String m_name;
	
	public ArticleVO() {}

	public ArticleVO(Integer a_no, Integer b_no, String thumb_uri, int m_no, String title, String content,
			Date created_at, Date modified_at) {
		super();
		this.a_no = a_no;
		this.b_no = b_no;
		this.thumb_uri = thumb_uri;
		this.m_no = m_no;
		this.title = title;
		this.content = content;
		this.created_at = created_at;
		this.modified_at = modified_at;
	}
	
	public ArticleVO(String thumb_uri, int m_no, String title, String content) {
		super();
		this.thumb_uri = thumb_uri;
		this.m_no = m_no;
		this.title = title;
		this.content = content;
	}
	
	public ArticleVO( Integer b_no, String thumb_uri, int m_no, String title, String content) {
		super();
		this.b_no = b_no;
		this.thumb_uri = thumb_uri;
		this.m_no = m_no;
		this.title = title;
		this.content = content;
	}
	public ArticleVO( Integer a_no, Integer b_no, String thumb_uri, int m_no, String title, String content) {
		super();
		this.a_no = a_no;
		this.b_no = b_no;
		this.thumb_uri = thumb_uri;
		this.m_no = m_no;
		this.title = title;
		this.content = content;
	}	
	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public Integer getA_no() {
		return a_no;
	}

	public void setA_no(Integer a_no) {
		this.a_no = a_no;
	}

	public Integer getB_no() {
		return b_no;
	}

	public void setB_no(Integer b_no) {
		this.b_no = b_no;
	}

	public String getThumb_uri() {
		return thumb_uri;
	}

	public void setThumb_uri(String thumb_uri) {
		this.thumb_uri = thumb_uri;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreated_at() {
		return created_at;
	}

	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}

	public Date getModified_at() {
		return modified_at;
	}

	public void setModified_at(Date modified_at) {
		this.modified_at = modified_at;
	}

	@Override
	public String toString() {
		return "ArticleVO [a_no=" + a_no + ", b_no=" + b_no + ", thumb_uri=" + thumb_uri + ", m_no=" + m_no + ", title="
				+ title + ", content=" + content + ", created_at=" + created_at + ", modified_at=" + modified_at + "]";
	}

	

}
