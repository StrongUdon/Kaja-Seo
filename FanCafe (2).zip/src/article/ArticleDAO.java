package article;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import board.BoardVO;
import board.Pager;
import reply.ReplyVO;
import util.DBConn;

public class ArticleDAO implements ArticleIDAO {
	public static final int TITLE = 1;
	public static final int CREATED_AT = 2;
	public static final int MODIFIED_AT = 3;
	private Connection con; 

	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public ArticleDAO() throws ClassNotFoundException, SQLException {
		con = new DBConn().getConnection();
				
	}

	
	@Override
	public boolean write(ArticleVO art) {
		
		String sql = "insert into articles"
				+ " (a_no, b_no, thumb_uri, m_no, title, content) values(article_increment.nextval, ?, ?, ?, ?, ?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, art.getB_no());
			pstmt.setString(2, art.getThumb_uri());
			pstmt.setInt(3, art.getM_no());
			pstmt.setString(4, art.getTitle());
			pstmt.setString(5, art.getContent());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Insert Exception");
			return false;
		}
		return true;
	}

	@Override
	public boolean update(ArticleVO avo) {

		String sql = "update articles set title = ? and content = ? and thumb_uri = ? modified_at = sysdate where a_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, avo.getTitle());
			pstmt.setString(2, avo.getContent());
			pstmt.setString(3, avo.getThumb_uri());
			pstmt.setInt(4, avo.getA_no());			
			if (pstmt.executeUpdate() ==1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Update Exception");

		}
		return false;
		
	}

	@Override
	public boolean delete_art(Integer a_no) {
		String sql = "delete from articles where a_no = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, a_no);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Delete Exception");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public ArticleVO getOneInfo(Integer a_no) throws SQLException {
		String sql = "select articles.*, m_name from articles, members where "
				+ " articles.m_no = members.m_no "
				+ " and a_no = ?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, a_no);
		rs = pstmt.executeQuery();
		ArticleVO av = new ArticleVO();
		if (rs.next()) {
			int b_no = rs.getInt("b_no");
			String thumb_uri = rs.getString("thumb_uri");
			int writer_no = rs.getInt("m_no");
			String title = rs.getString("title");
			String content = rs.getString("content");
			Date c_day = rs.getDate("created_at");
			Date m_day = rs.getDate("modified_at");

			av = new ArticleVO (a_no, b_no, thumb_uri, writer_no, title, content, c_day, m_day);
			av.setM_name(rs.getString("m_name"));
			System.out.println(av.toString());
		}
		return av;
	}

	@Override
	public ArrayList<ArticleVO> getAllInfo(int b_no, int field, int index, Pager pg) throws SQLException {
		ArrayList<ArticleVO> art_list = new ArrayList<>();
		String sql = "select ROWNUM, x.*, members.m_name " + 
				" from (select ROWNUM rn, art.* from articles art order by ? ) x, members " + 
				" where b_no = ? and ROWNUM < ? and rn >= ? and x.m_no = members.m_no";
		pstmt = con.prepareStatement(sql);
		String order;
		pg.setCurr(index);
		switch(field) {
		case TITLE:
			order= "TITLE";
			break;

		case MODIFIED_AT: 
			order= "MODIFIED_AT";
			break;
		default: 
			order= "CREATED_AT";
			break;
		}
		int start = (pg.getCurr())*5 - 5 ;
		System.out.println(start + "start");
		pstmt.setString(1, order);
		pstmt.setInt(2, b_no);
		pstmt.setInt(3, (start + 5) );
		pstmt.setInt(4, start);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			Integer article_no = rs.getInt("a_no");
			int board_no = rs.getInt("b_no");
			String thumb_uri = rs.getString("thumb_uri");
			int writer_no = rs.getInt("m_no");
			String title = rs.getString("title");
			String content = rs.getString("content");
			Date c_day = rs.getDate("created_at");
			Date m_day = rs.getDate("modified_at");
			String m_name = rs.getString("m_name");
			
			ArticleVO av = new ArticleVO (article_no, board_no, thumb_uri, writer_no, title, content, c_day, m_day);
			av.setM_name(m_name);
			art_list.add(av);

		}
		return art_list;
	}

	
	public int count(int b_no) {
		String sql = "SELECT count(*) "
				+ " FROM articles where b_no = ? ";
		int cnt =-1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();
			rs.next();
			cnt = rs.getInt("count(*)");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cnt;
	}



}
