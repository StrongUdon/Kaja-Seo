package article;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import board.Pager;

public interface ArticleIDAO {

	public boolean write(ArticleVO art);
	// 글쓰기(ArticleVo 받아서 성공/실패)
	
	public boolean update(ArticleVO art);
	// 수정(content 받아서 성공/실패)
	// writer=email 인지 아닌지는 후에 판단 controller 에서.

	public boolean delete_art(Integer article_no);
	// 게시물 삭제(article_no 받아서 성공/실패) 

	public ArticleVO getOneInfo(Integer article_no) throws SQLException;
	// 게시물 클릭해서 상세내용 읽는거 (article_no 받아서 ArticleVO 반환)
	
	public ArrayList<ArticleVO> getAllInfo(int b_no, int field, int index, Pager pg) throws SQLException ;
	// 게시물 전체 내용 반환 이건 dao에서 생성시간순으로 나열할거임
}
